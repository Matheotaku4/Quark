//! Modèle sérialisable commun aux bibliothèques des boutiques.

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Provider {
    Steam,
    Epic,
    Gog,
    Itch,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ProviderGameKey {
    pub provider: Provider,
    pub product_id: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "state", content = "reason")]
#[derive(Default)]
pub enum CapabilityState {
    Supported,
    Unsupported(String),
    #[default]
    Unknown,
    RequiresSetup(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct GameCapabilities {
    pub achievements: CapabilityState,
    pub cloud_saves: CapabilityState,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum InstallState {
    #[default]
    Unknown,
    NotInstalled,
    Queued,
    Installing,
    Installed,
    Updating,
    Repairing,
    Failed,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct ProviderGame {
    pub key: ProviderGameKey,
    pub title: String,
    pub owned: bool,
    pub install_path: Option<PathBuf>,
    /// Racine choisie lors de l'installation (Epic/GOG/Steam). Sert à refuser
    /// toute suppression récursive hors de cette racine.
    #[serde(default)]
    pub install_root: Option<PathBuf>,
    #[serde(default)]
    pub custom_save_paths: Vec<PathBuf>,
    pub install_state: InstallState,
    /// Image de couverture publiée par la boutique (jamais un secret).
    #[serde(default)]
    pub cover_url: Option<String>,
    /// Exécutable relatif au dossier installé, quand la boutique le publie.
    #[serde(default)]
    pub install_exe: Option<PathBuf>,
    /// Identifiant de la fiche Quark associée, si elle existe.
    pub quark_game_id: Option<String>,
    pub capabilities: GameCapabilities,
    pub last_synced: Option<i64>,
}

impl Default for ProviderGame {
    fn default() -> Self {
        Self {
            key: ProviderGameKey {
                provider: Provider::Steam,
                product_id: String::new(),
            },
            title: String::new(),
            owned: false,
            install_path: None,
            install_root: None,
            custom_save_paths: Vec::new(),
            cover_url: None,
            install_exe: None,
            install_state: InstallState::Unknown,
            quark_game_id: None,
            capabilities: GameCapabilities::default(),
            last_synced: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct ManualGameGroup {
    /// Les identifiants de fournisseurs réunis volontairement par l'utilisateur.
    pub members: Vec<ProviderGameKey>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct ProviderLibrary {
    pub games: Vec<ProviderGame>,
    pub manual_groups: Vec<ManualGameGroup>,
}
