//! Couvertures des jeux de boutiques, téléchargées une fois puis lues du disque.
//!
//! Steam et GOG publient une URL de couverture dans leurs réponses ; Epic ne
//! publie pas d'URL dérivable, donc elle est demandée à Legendary pour le seul
//! jeu concerné puis mémorisée dans la bibliothèque des boutiques. Aucune clé
//! n'est utilisée et aucune requête n'est faite au moment du rendu.

use super::model::{Provider, ProviderGame, ProviderGameKey};
use std::io::Cursor;
use std::path::{Path, PathBuf};
use std::time::Duration;

/// Version du cache. La v2 est née avec les URLs GOG corrigées : les images
/// dérivées de `images.background` (mauvais jeu) ne doivent jamais être
/// réutilisées.
const CACHE_VERSION: &str = "v2";

/// Dossier des couvertures de boutiques, à côté des artworks des jeux Quark.
pub fn cache_dir() -> PathBuf {
    crate::config::artwork_root()
        .join("provider-covers")
        .join(CACHE_VERSION)
}

fn provider_stem(provider: Provider) -> &'static str {
    match provider {
        Provider::Steam => "steam",
        Provider::Epic => "epic",
        Provider::Gog => "gog",
        Provider::Itch => "itch",
    }
}

/// Nom de fichier stable : l'identifiant de boutique peut contenir des
/// caractères qui n'ont pas leur place dans un nom de fichier.
fn safe_id(product_id: &str) -> String {
    product_id
        .chars()
        .map(|character| {
            if character.is_ascii_alphanumeric() || matches!(character, '-' | '_' | '.') {
                character
            } else {
                '_'
            }
        })
        .collect()
}

pub fn cache_path(key: &ProviderGameKey) -> PathBuf {
    cache_dir().join(format!(
        "{}-{}.png",
        provider_stem(key.provider),
        safe_id(&key.product_id)
    ))
}

/// Bannière large d'un jeu de boutique, dans le même cache que la jaquette.
pub fn hero_cache_path(key: &ProviderGameKey) -> PathBuf {
    cache_dir().join(format!(
        "hero-{}-{}.png",
        provider_stem(key.provider),
        safe_id(&key.product_id)
    ))
}

fn cached_file(path: &Path) -> Option<PathBuf> {
    let usable = std::fs::metadata(path)
        .map(|meta| meta.len() > 512)
        .unwrap_or(false);
    usable.then(|| path.to_path_buf())
}

/// Couverture déjà téléchargée (fichier non vide), ou rien.
pub fn cached(key: &ProviderGameKey) -> Option<PathBuf> {
    cached_file(&cache_path(key))
}

/// Bannière déjà téléchargée (fichier non vide), ou rien.
pub fn cached_hero(key: &ProviderGameKey) -> Option<PathBuf> {
    cached_file(&hero_cache_path(key))
}

fn write_atomic(path: &Path, bytes: &[u8]) -> Result<(), String> {
    use std::io::Write;
    let parent = path
        .parent()
        .ok_or_else(|| "dossier de couvertures introuvable".to_string())?;
    std::fs::create_dir_all(parent)
        .map_err(|_| "impossible de créer le dossier de couvertures".to_string())?;
    let temp = parent.join(format!(
        ".{}-{}.tmp",
        path.file_stem()
            .and_then(|stem| stem.to_str())
            .unwrap_or("cover"),
        std::process::id()
    ));
    let mut file = std::fs::File::create(&temp)
        .map_err(|_| "impossible d'écrire la couverture".to_string())?;
    if file
        .write_all(bytes)
        .and_then(|()| file.sync_all())
        .is_err()
    {
        let _ = std::fs::remove_file(&temp);
        return Err("impossible d'écrire la couverture".to_string());
    }
    drop(file);
    std::fs::rename(&temp, path).map_err(|_| {
        let _ = std::fs::remove_file(&temp);
        "impossible de remplacer la couverture".to_string()
    })
}

/// Télécharge l'image et la réécrit en PNG : le format servi par la boutique
/// (jpeg, webp) n'a plus d'importance, et une image illisible est refusée
/// plutôt que mise en cache.
pub fn download(url: &str, key: &ProviderGameKey) -> Result<PathBuf, String> {
    download_as(url, &cache_path(key), false)
}

/// Télécharge la bannière large, en refusant une image verticale : sans ce
/// contrôle, une jaquette se retrouvait étirée derrière la fiche du jeu.
pub fn download_hero(url: &str, key: &ProviderGameKey) -> Result<PathBuf, String> {
    download_as(url, &hero_cache_path(key), true)
}

fn download_as(url: &str, path: &Path, wide: bool) -> Result<PathBuf, String> {
    if !(url.starts_with("https://") || url.starts_with("http://")) {
        return Err("image de boutique sans adresse valide".to_string());
    }
    let response = crate::artwork::http()
        .get(url)
        .timeout(Duration::from_secs(30))
        .send()
        .map_err(|_| "image de boutique injoignable".to_string())?;
    if !response.status().is_success() {
        return Err(format!(
            "image refusée par la boutique (HTTP {})",
            response.status().as_u16()
        ));
    }
    let bytes = crate::net::bytes(response, 12 * 1024 * 1024, "image de boutique")?;
    let image =
        image::load_from_memory(&bytes).map_err(|_| "image de boutique illisible".to_string())?;
    if image.width() < 96 || image.height() < 96 {
        return Err("image de boutique trop petite".to_string());
    }
    if wide && image.width() <= image.height() {
        return Err("la boutique n'a pas fourni de bannière large".to_string());
    }
    let mut buffer = Cursor::new(Vec::new());
    image
        .write_to(&mut buffer, image::ImageFormat::Png)
        .map_err(|_| "image de boutique non convertible".to_string())?;
    write_atomic(path, &buffer.into_inner())?;
    Ok(path.to_path_buf())
}

/// Couverture d'un jeu : celle du cache, sinon résolue auprès de la boutique
/// puis téléchargée. Retourne aussi l'URL découverte, à mémoriser dans la
/// bibliothèque pour éviter une nouvelle résolution.
///
/// GOG est toujours résolu par son API v2 : les fiches produits ne publient
/// qu'une image d'arrière-plan, dont l'identifiant ne sert pas la jaquette
/// verticale — l'ancienne déduction affichait l'image d'un autre jeu.
/// Toutes les images d'un jeu de boutique : jaquette et bannière. Les deux
/// téléchargements sont indépendants ; l'un peut réussir sans l'autre.
#[derive(Debug, Default)]
pub struct ProviderArt {
    pub cover: Option<(PathBuf, Option<String>)>,
    pub hero: Option<(PathBuf, Option<String>)>,
}

pub fn ensure_all(game: &ProviderGame) -> ProviderArt {
    ProviderArt {
        cover: ensure(game).ok(),
        hero: ensure_hero(game).ok(),
    }
}

pub fn ensure(game: &ProviderGame) -> Result<(PathBuf, Option<String>), String> {
    if let Some(path) = cached(&game.key) {
        return Ok((path, None));
    }
    let mut errors: Vec<String> = Vec::new();
    let candidate = match game.key.provider {
        Provider::Steam => steam_cover_url(&game.key.product_id).or_else(|| game.cover_url.clone()),
        Provider::Gog => match super::gog_library::cover_url(&game.key.product_id) {
            Ok(url) => Some(url),
            Err(error) => {
                errors.push(error);
                None
            }
        },
        Provider::Epic => match game.cover_url.clone() {
            Some(url) => Some(url),
            None => match super::legendary::epic_cover_url(&game.key.product_id) {
                Ok(url) => Some(url),
                Err(error) => {
                    errors.push(error);
                    None
                }
            },
        },
        Provider::Itch => game.cover_url.clone(),
    };
    if let Some(url) = candidate {
        match download(&url, &game.key) {
            Ok(path) => return Ok((path, Some(url))),
            Err(error) => errors.push(error),
        }
    }
    // Repli Steam : la jaquette verticale de la fiche du même titre. Elle est
    // préférée à un monogramme, sans jamais remplacer une image de la boutique
    // quand celle-ci existe.
    if game.key.provider != Provider::Steam
        && let Some((url, _app_id)) = steam_fallback(&game.title)
    {
        match download(&url, &game.key) {
            Ok(path) => return Ok((path, Some(url))),
            Err(error) => errors.push(error),
        }
    }
    Err(errors
        .into_iter()
        .next()
        .unwrap_or_else(|| "aucune couverture disponible".to_string()))
}

/// Bannière large d'un jeu : image officielle de la boutique, sinon bannière
/// Steam du même titre. Une jaquette verticale n'est jamais utilisée ici.
pub fn ensure_hero(game: &ProviderGame) -> Result<(PathBuf, Option<String>), String> {
    if let Some(path) = cached_hero(&game.key) {
        return Ok((path, None));
    }
    let mut errors: Vec<String> = Vec::new();
    let candidate = match game.key.provider {
        Provider::Steam => steam_hero_url(&game.key.product_id),
        Provider::Gog => match super::gog_library::hero_url(&game.key.product_id) {
            Ok(url) => Some(url),
            Err(error) => {
                errors.push(error);
                None
            }
        },
        Provider::Epic => match super::legendary::epic_hero_url(&game.key.product_id) {
            Ok(url) => Some(url),
            Err(error) => {
                errors.push(error);
                None
            }
        },
        Provider::Itch => None,
    };
    if let Some(url) = candidate {
        match download_hero(&url, &game.key) {
            Ok(path) => return Ok((path, Some(url))),
            Err(error) => errors.push(error),
        }
    }
    if game.key.provider != Provider::Steam
        && let Some((_url, app_id)) = steam_fallback(&game.title)
        && let Some(url) = steam_hero_url(&app_id.to_string())
    {
        match download_hero(&url, &game.key) {
            Ok(path) => return Ok((path, Some(url))),
            Err(error) => errors.push(error),
        }
    }
    Err(errors
        .into_iter()
        .next()
        .unwrap_or_else(|| "aucune bannière disponible".to_string()))
}

/// Jaquette verticale d'un jeu Steam à partir de son AppID.
pub fn steam_cover_url(app_id: &str) -> Option<String> {
    let app_id = app_id.trim();
    if app_id.is_empty() || !app_id.chars().all(|character| character.is_ascii_digit()) {
        return None;
    }
    Some(format!(
        "https://cdn.cloudflare.steamstatic.com/steam/apps/{app_id}/library_600x900.jpg"
    ))
}

/// Bannière large d'un jeu Steam à partir de son AppID.
pub fn steam_hero_url(app_id: &str) -> Option<String> {
    let app_id = app_id.trim();
    if app_id.is_empty() || !app_id.chars().all(|character| character.is_ascii_digit()) {
        return None;
    }
    Some(format!(
        "https://cdn.cloudflare.steamstatic.com/steam/apps/{app_id}/library_hero.jpg"
    ))
}

/// Cherche le jeu sur le catalogue Steam et renvoie la jaquette du meilleur
/// titre. Aucune image n'est inventée si la recherche ne correspond pas.
fn steam_fallback(title: &str) -> Option<(String, u32)> {
    let client = crate::artwork::http();
    let items = crate::steam_store::search(&client, title, "english", "US").ok()?;
    let wanted = normalize(title);
    if wanted.is_empty() {
        return None;
    }
    let exact = items
        .iter()
        .find(|item| normalize(&item.name) == wanted)
        .or_else(|| {
            items.iter().find(|item| {
                let candidate = normalize(&item.name);
                candidate.contains(&wanted) || wanted.contains(&candidate)
            })
        })?;
    let url = steam_cover_url(&exact.app_id.to_string())?;
    Some((url, exact.app_id))
}

fn normalize(title: &str) -> String {
    title
        .to_lowercase()
        .chars()
        .map(|character| {
            if character.is_alphanumeric() {
                character
            } else {
                ' '
            }
        })
        .collect::<String>()
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key(provider: Provider, id: &str) -> ProviderGameKey {
        ProviderGameKey {
            provider,
            product_id: id.into(),
        }
    }

    #[test]
    fn chaque_boutique_a_un_nom_de_fichier_distinct_et_sur() {
        let steam = cache_path(&key(Provider::Steam, "620"));
        let epic = cache_path(&key(Provider::Epic, "../../etc/passwd"));
        assert!(steam.ends_with("steam-620.png"));
        assert!(epic.ends_with("epic-.._.._etc_passwd.png"));
        assert_ne!(steam, epic);
    }

    #[test]
    fn une_couverture_absente_ou_vide_n_est_pas_consideree_comme_cachee() {
        // Le dossier de cache réel n'est pas touché : on teste seulement la
        // décision sur un chemin qui n'existe pas.
        let missing = cache_path(&key(Provider::Gog, "does-not-exist-42"));
        let _ = std::fs::remove_file(&missing);
        assert!(cached(&key(Provider::Gog, "does-not-exist-42")).is_none());
    }

    #[test]
    fn la_jaquette_steam_de_repli_ne_devine_pas_l_appid_et_normalise_le_titre() {
        assert_eq!(
            steam_cover_url("620").unwrap(),
            "https://cdn.cloudflare.steamstatic.com/steam/apps/620/library_600x900.jpg"
        );
        assert!(steam_cover_url("app_123").is_none());
        assert!(steam_cover_url("").is_none());
        assert_eq!(
            steam_hero_url("620").unwrap(),
            "https://cdn.cloudflare.steamstatic.com/steam/apps/620/library_hero.jpg"
        );
        assert!(steam_hero_url("app_123").is_none());
        assert_ne!(
            hero_cache_path(&key(Provider::Steam, "620")),
            cache_path(&key(Provider::Steam, "620"))
        );
        assert!(hero_cache_path(&key(Provider::Steam, "620")).ends_with("hero-steam-620.png"));
        assert_eq!(
            normalize("The Witcher 3: Wild Hunt"),
            "the witcher 3 wild hunt"
        );
        assert_eq!(normalize("  Portal  2  "), "portal 2");
    }

    #[test]
    fn une_adresse_non_http_est_refusee_avant_toute_requete() {
        let result = download("file:///etc/passwd", &key(Provider::Steam, "1"));
        assert!(result.unwrap_err().contains("adresse"));
    }
}
