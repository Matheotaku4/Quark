//! Types communs à la bibliothèque unifiée des boutiques.
//!
//! Les adaptateurs concrets (Steam, Epic, GOG) restent dans des modules
//! séparés ; ces types ne contiennent aucune donnée d'authentification.

pub mod achievements;
pub mod cloud_saves;
pub mod covers;
pub mod credentials;
pub mod epic_account;
pub mod epic_library;
pub mod gog;
pub mod gog_library;
pub mod itch;
pub mod legendary;
pub mod model;
pub mod operations;
pub mod playtime;
pub mod runner;
pub mod steam;
pub mod tools;

pub use achievements::{AchievementInfo, AchievementRow, SessionUnlock};
pub use cloud_saves::SyncReport as CloudSaveReport;
pub use model::{
    CapabilityState, GameCapabilities, InstallState, Provider, ProviderGame, ProviderGameKey,
    ProviderLibrary,
};
pub use playtime::PlaytimeState;
/// Vrai quand un fichier de session a été créé ou réécrit entre deux relevés.
///
/// Legendary et gogdl sortent parfois avec le code 0 en cas de refus : c'est
/// l'écriture du fichier de session qui prouve la connexion. Le contenu est
/// comparé plutôt que l'horodatage, dont la résolution peut être grossière.
/// Taille d'installation publiée par `legendary info` ou `gogdl info`.
///
/// Les deux outils changent de forme selon leur version : on cherche donc les
/// clés connues au premier niveau, puis récursivement, en acceptant un nombre
/// ou une chaîne de chiffres. Aucune valeur n'est inventée quand la réponse ne
/// la contient pas.
pub fn install_size_from_json(text: &str) -> Option<u64> {
    let root = first_json_value(text)?;
    fn find(value: &serde_json::Value, depth: usize) -> Option<u64> {
        if depth > 6 {
            return None;
        }
        match value {
            serde_json::Value::Object(map) => {
                for key in [
                    "install_size",
                    "download_size",
                    "disk_size",
                    "total_size",
                    "size",
                ] {
                    if let Some(size) = map.get(key).and_then(|value| match value {
                        serde_json::Value::Number(number) => number.as_u64(),
                        serde_json::Value::String(text) => text.trim().parse::<u64>().ok(),
                        _ => None,
                    }) && size > 0
                    {
                        return Some(size);
                    }
                }
                map.values().find_map(|value| find(value, depth + 1))
            }
            serde_json::Value::Array(items) => {
                items.iter().find_map(|value| find(value, depth + 1))
            }
            _ => None,
        }
    }
    find(&root, 0)
}

/// Première valeur JSON complète d'une sortie d'outil, même entourée de
/// lignes de journal : Legendary et gogdl écrivent parfois `[INFO] …` avant
/// ou après le JSON. `serde_json::from_str` refusait alors toute la sortie,
/// ce qui faisait échouer une installation GOG pourtant valide.
pub fn first_json_value(text: &str) -> Option<serde_json::Value> {
    let mut rest = text;
    while let Some(index) = rest.find('{') {
        let candidate = &rest[index..];
        let mut stream =
            serde_json::Deserializer::from_str(candidate).into_iter::<serde_json::Value>();
        match stream.next() {
            Some(Ok(value)) => return Some(value),
            Some(Err(error)) if error.is_eof() => return None,
            _ => rest = &candidate[1..],
        }
    }
    None
}

/// Premier objet JSON qui contient `key`. Les journaux de gogdl peuvent
/// contenir des accolades ; on ignore les objets qui ne portent pas la clé
/// attendue au lieu de renoncer à lire la sortie.
pub fn json_object_with_key(text: &str, key: &str) -> Option<serde_json::Value> {
    let mut rest = text;
    while let Some(index) = rest.find('{') {
        let candidate = &rest[index..];
        let mut stream =
            serde_json::Deserializer::from_str(candidate).into_iter::<serde_json::Value>();
        match stream.next() {
            Some(Ok(value)) => {
                if value.get(key).is_some() {
                    return Some(value);
                }
                let consumed = stream.byte_offset();
                rest = &candidate[consumed..];
            }
            Some(Err(error)) if error.is_eof() => return None,
            _ => rest = &candidate[1..],
        }
    }
    None
}

/// Un dossier d'installation ne suffit pas à lui seul : pour GOG, le manifeste
/// et l'exécutable qu'il déclare doivent encore être présents. Toute bascule
/// vers « installé » (sonde, reprise, synchronisation) passe par ici.
pub fn install_directory_is_complete(key: &ProviderGameKey, path: &std::path::Path) -> bool {
    path.is_dir()
        && (key.provider != Provider::Gog || gog::is_complete_install(path, &key.product_id))
}

/// Lignes de diagnostic sur les connexions GOG et Epic, ajoutées au journal de
/// session avant chaque lancement. Aucun jeton ni code d'autorisation n'y est
/// écrit : seulement la présence des sessions et des outils, et la boutique du
/// jeu lancé quand elle est connue. Le préfixe Wine permet de reconnaître un
/// overlay EOS installé par le launcher Epic dans le préfixe du jeu.
pub fn connection_diagnostics(
    key: Option<&ProviderGameKey>,
    wine_prefix: Option<&std::path::Path>,
) -> Vec<String> {
    let mut lines = Vec::new();
    if let Some(key) = key {
        let boutique = match key.provider {
            Provider::Steam => "Steam",
            Provider::Epic => "Epic Games",
            Provider::Gog => "GOG",
            Provider::Itch => "itch.io",
        };
        lines.push(format!("{boutique} · produit {}", key.product_id));
    }
    lines.push(format!(
        "GOG · session gogdl {}",
        if gog::GogAdapter::is_logged_in() {
            "connectée"
        } else {
            "absente"
        }
    ));
    let gogdl = tools::ManagedToolId::Gogdl.installed_path();
    lines.push(format!(
        "GOG · gogdl {} ({})",
        gogdl.display(),
        if gogdl.is_file() {
            "présent"
        } else {
            "absent"
        }
    ));
    lines.push(format!(
        "Epic · session directe {}",
        if epic_account::connected_account().is_some() {
            "connectée"
        } else {
            "absente"
        }
    ));
    lines.push(format!(
        "Epic · session Legendary {}",
        if legendary::LegendaryAdapter::is_logged_in() {
            "connectée"
        } else {
            "absente"
        }
    ));
    let overlay = legendary::LegendaryAdapter::eos_overlay_installed_path().or_else(|| {
        wine_prefix.and_then(legendary::LegendaryAdapter::eos_overlay_installed_for_prefix)
    });
    lines.push(format!(
        "Epic · overlay EOS {}",
        match overlay {
            Some(path) => format!("installé ({})", path.display()),
            None => "absent (à installer dans Paramètres → Boutiques & outils)".to_string(),
        }
    ));
    let legendary = tools::ManagedToolId::Legendary.installed_path();
    lines.push(format!(
        "Epic · legendary {} ({})",
        legendary.display(),
        if legendary.is_file() {
            "présent"
        } else {
            "absent"
        }
    ));
    lines
}

pub fn session_written(before: Option<&[u8]>, after: Option<&[u8]>) -> bool {
    match (before, after) {
        (_, None) => false,
        (None, Some(_)) => true,
        (Some(before), Some(after)) => before != after,
    }
}

#[cfg(test)]
mod tests {
    use super::{connection_diagnostics, install_size_from_json, session_written};

    #[test]
    fn la_taille_d_installation_est_lue_dans_les_formes_connues() {
        assert_eq!(
            install_size_from_json(r#"{"install_size": 6442450944}"#),
            Some(6_442_450_944)
        );
        assert_eq!(
            install_size_from_json(r#"{"folder_name":"Game","size":"4294967296"}"#),
            Some(4_294_967_296)
        );
        assert_eq!(
            install_size_from_json(r#"{"data":{"download_size":123456}}"#),
            Some(123_456)
        );
        assert_eq!(install_size_from_json(r#"{"title":"sans taille"}"#), None);
        assert_eq!(install_size_from_json("pas du json"), None);
    }

    #[test]
    fn les_diagnostics_de_connexion_n_exposent_aucun_secret() {
        for (provider, product_id, label) in [
            (super::Provider::Gog, "2015389384", "GOG"),
            (super::Provider::Epic, "app_123", "Epic"),
        ] {
            let key = super::ProviderGameKey {
                provider,
                product_id: product_id.to_string(),
            };
            let lines = connection_diagnostics(Some(&key), None).join("\n");
            assert!(lines.contains(label));
            assert!(lines.contains(product_id));
            assert!(lines.contains("GOG"));
            assert!(lines.contains("Epic"));
            assert!(!lines.contains("access_token"));
            assert!(!lines.contains("refresh_token"));
            assert!(!lines.contains("authorizationCode"));
        }
        let lines = connection_diagnostics(None, None).join("\n");
        assert!(lines.contains("GOG"));
        assert!(lines.contains("Epic"));
    }

    #[test]
    fn un_overlay_installe_dans_le_prefixe_est_diagnostique_present() {
        let prefix = std::env::temp_dir().join(format!(
            "quark-overlay-prefix-{}-{}",
            std::process::id(),
            crate::config::now_ts()
        ));
        let overlay =
            prefix.join("drive_c/Program Files (x86)/Epic Games/Launcher/Portal/Extras/Overlay");
        std::fs::create_dir_all(&overlay).unwrap();
        std::fs::write(overlay.join("EOSOVH-Win64-Shipping.dll"), b"dll").unwrap();
        let lines = connection_diagnostics(None, Some(&prefix)).join("\n");
        assert!(lines.contains("overlay EOS installé"), "{lines}");
        let _ = std::fs::remove_dir_all(&prefix);
    }

    #[test]
    fn une_session_absente_ou_inchangee_ne_prouve_pas_une_connexion() {
        assert!(!session_written(None, None));
        assert!(!session_written(Some(b"a"), Some(b"a")));
        assert!(!session_written(Some(b"a"), None));
        assert!(session_written(None, Some(b"a")));
        assert!(session_written(Some(b"a"), Some(b"b")));
    }
}
