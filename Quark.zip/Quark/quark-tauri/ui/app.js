"use strict";
// Actions, événements globaux, palette de commandes et démarrage.

const acts = {
  play: () => run(async () => {
    const g = game(app.sel); if (!g) return;
    if (app.running.has(g.id)) { const r = await invoke("stop_game", { id: g.id }); app.running.set(g.id, { ...app.running.get(g.id), ...r, at: Date.now(), stopping: true }); }
    else { setGame(await invoke("launch_game", { id: g.id })); app.running.set(g.id, { id: g.id, elapsed: 0, at: Date.now(), label: "" }); toast(t("toast.launched", { name: g.name })); }
    renderList(); renderSheet();
  }),
  fav: () => run(async () => { const g = game(app.sel); setGame(await invoke("set_favorite", { id: g.id, favorite: !g.favorite })); renderList(); renderSheet(); }),
  gsettings: () => gameSettingsModal(), customize: () => customizeModal(), log: () => logModal(), remove: () => removeModal(), add: () => addModal(),
  settings: () => setView(app.view === "settings" ? "library" : "settings"), close: () => closeModal(), palette: () => palette(), updates: () => updatesModal(),
  back: () => { app.open = false; renderSheet(); },
  "toggle-view": () => run(async () => { await cfgSet({ view: app.cfg.view === "grid" ? "list" : "grid" }); app.open = false; app.view = "library"; renderAll(); }),
  "news-refresh": () => { const g = game(app.sel); g && loadNews(g, true); },
  "reset-filters": () => { app.f = { status: "", genre: "", tag: "", fav: false }; renderSide(); renderList(); renderSheet(); },
};

// ---------- palette (Ctrl+K) ----------
function palette() {
  app.pal = { q: "", i: 0 };
  $("#modal").innerHTML = `<div class="scrim" data-act="close-scrim"><div class="pal"><input id="pq" placeholder="${esc(t("x.palette"))}" autocomplete="off" spellcheck="false"><div class="res" id="pres"></div></div></div>`;
  const input = $("#pq"); input.focus(); input.oninput = () => { app.pal = { q: input.value, i: 0 }; palList(); }; palList();
}
function palItems() {
  const q = norm(app.pal.q.trim());
  const games = app.data.games.filter((g) => !q || norm(g.name).includes(q)).sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0)).slice(0, 8).map((g) => ({ label: g.name, hint: rel(g.lastPlayed), go: () => { app.view = "library"; renderAll(); select(g.id); }, play: g.id }));
  const actions = [[t("add.title"), addModal], [t("settings.title"), () => setView("settings")], [t("x.home"), () => setView("home")], [t("nav.library"), () => setView("library")]].filter(([l]) => !q || norm(l).includes(q)).map(([label, go]) => ({ label, hint: "", go, action: true }));
  return [...games, ...actions];
}
function palList() {
  const items = palItems(); app.pal.items = items;
  $("#pres").innerHTML = items.length ? items.map((x, n) => `<button data-n="${n}" class="${n === app.pal.i ? "on" : ""}">${ic(x.action ? "plus" : "play")}<span>${esc(x.label)}</span><small>${esc(x.hint)}</small></button>`).join("") : `<div class="none">${esc(t("x.none"))}</div>`;
}
function palGo(n, play) { const x = app.pal.items[n]; if (!x) return; closeModal(); x.go(); if (play && x.play) setTimeout(acts.play, 0); }

// ---------- événements ----------
document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-act]");
  if (a && a.dataset.act === "close-scrim") { if (e.target === a) closeModal(); }
  else if (a) { const d = a.closest("details"); d && (d.open = false); acts[a.dataset.act]?.(); }
  const v = e.target.closest("[data-view]"); if (v) setView(v.dataset.view);
  const r = e.target.closest(".row, .tile"); if (r) {
    if (r.dataset.go) { app.view = "library"; app.open = true; renderAll(); select(r.dataset.id); if (r.dataset.launch) setTimeout(acts.play, 0); } else select(r.dataset.id);
  }
  const gr = e.target.closest("[data-group]"); if (gr) { const k = gr.dataset.group; app.collapsed.has(k) ? app.collapsed.delete(k) : app.collapsed.add(k); renderList(); }
  const tb = e.target.closest("[data-tab]"); if (tb) { app.tab = tb.dataset.tab; $$(".tabs [data-tab]").forEach((b) => b.classList.toggle("on", b === tb)); const g = game(app.sel); g && renderTab(g); }
  const s = e.target.closest("[data-status]"); if (s) { const d = s.closest("details"); d && (d.open = false); run(async () => { setGame(await invoke("set_status", { id: app.sel, status: s.dataset.status })); renderList(); renderSheet(); }); }
  const st = e.target.closest("[data-stab]"); if (st) { app.stab = st.dataset.stab; app.sq = ""; renderSheet(); }
  const th = e.target.closest("[data-theme]"); if (th) run(async () => { await cfgSet({ theme: th.dataset.theme }); renderSheet(); });
  const o = e.target.closest("[data-open]"); if (o && o.dataset.open) run(() => invoke("open_url", { target: o.dataset.open }));
  const hi = e.target.closest("[data-hi]"); if (hi) { app.hi = +hi.dataset.hi; app.hTick = 0; renderSheet(); }
  const w = e.target.closest("[data-win]"); if (w) invoke(w.dataset.win, {});
  const pn = e.target.closest("#pres [data-n]"); if (pn) palGo(+pn.dataset.n);
  $$("details.menu[open]").forEach((d) => d.contains(e.target) || (d.open = false));
});
$("#q").addEventListener("input", (e) => { app.query = e.target.value; renderList(); if (document.body.classList.contains("grid")) renderSheet(); });
document.addEventListener("change", (e) => {
  const id = e.target.id; if (!id) return;
  if (id === "sort") run(() => cfgSet({ library_sort: e.target.value })).then(renderList);
  else if (id === "group") run(() => cfgSet({ group_by: e.target.value })).then(renderList);
  else if (id.startsWith("f-")) { app.f = { status: $("#f-status").value, genre: $("#f-genre").value, tag: $("#f-tag").value, fav: $("#f-fav").checked }; renderList(); if (document.body.classList.contains("grid")) renderSheet(); }
});
document.addEventListener("keydown", (e) => {
  if (app.pal) {
    const n = app.pal.items.length;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); app.pal.i = (app.pal.i + (e.key === "ArrowDown" ? 1 : n - 1)) % Math.max(1, n); palList(); }
    else if (e.key === "Enter") palGo(app.pal.i, e.shiftKey); else if (e.key === "Escape") closeModal();
    return;
  }
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName), lib = app.view === "library" && !$("#modal").firstChild;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); palette(); }
  else if (e.key === "Escape") { if ($("#modal").firstChild) closeModal(); else if (app.query) { app.query = $("#q").value = ""; $("#q").blur(); renderList(); } else if (app.view === "settings") setView("library"); }
  else if (e.key === "/" && !typing && lib) { e.preventDefault(); $("#q").focus(); }
  else if (!typing && lib && !document.body.classList.contains("grid") && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
    e.preventDefault(); const l = filtered(), i = l.findIndex((g) => g.id === app.sel), n = l[Math.max(0, Math.min(l.length - 1, i + (e.key === "ArrowDown" ? 1 : -1)))]; n && select(n.id);
  } else if (!typing && lib && e.key === "Enter") { e.preventDefault(); acts.play(); }
});

function tick() {
  $$("[data-live]").forEach((el) => (el.textContent = clock(elapsed(el.dataset.live))));
  if (app.view === "home" && app.cfg.carousel_auto && !$("#modal").firstChild) { app.hTick = (app.hTick || 0) + 1; if (app.hTick >= (app.cfg.carousel_secs || 8)) { app.hTick = 0; app.hi = (app.hi || 0) + 1; renderSheet(); } }
}
function wireWindow() {
  const d = $("#top");
  d.addEventListener("mousedown", (e) => e.button === 0 && !e.target.closest("button,input") && invoke("win_start_drag", {}));
  d.addEventListener("dblclick", (e) => !e.target.closest("button,input") && invoke("win_toggle_maximize", {}));
  const E = { n: "top:0;left:6px;right:6px;height:4px;cursor:ns-resize", s: "bottom:0;left:6px;right:6px;height:4px;cursor:ns-resize", e: "right:0;top:6px;bottom:6px;width:4px;cursor:ew-resize", w: "left:0;top:6px;bottom:6px;width:4px;cursor:ew-resize", ne: "top:0;right:0;width:8px;height:8px;cursor:nesw-resize", nw: "top:0;left:0;width:8px;height:8px;cursor:nwse-resize", se: "bottom:0;right:0;width:8px;height:8px;cursor:nwse-resize", sw: "bottom:0;left:0;width:8px;height:8px;cursor:nesw-resize" };
  for (const [dir, css] of Object.entries(E)) { const h = Object.assign(document.createElement("div"), { className: "rz" }); h.style.cssText = css; h.onmousedown = (e) => { e.preventDefault(); invoke("win_start_resize", { direction: dir }); }; document.body.append(h); }
}

async function boot() {
  wireWindow();
  app.data = await invoke("bootstrap_data");
  Object.assign(app.cfg, await invoke("get_settings_raw"));
  setRunning(app.data.running);
  const withHero = app.data.games.filter((g) => g.heroUrl); app.bgGame = withHero.length ? withHero[Math.floor(Math.random() * withHero.length)].id : null;
  applySettings();
  app.view = ({ home: "home", library: "library", store: "store", my_games: "mygames" })[app.cfg.start_page] || "library";
  let saved = null; try { saved = localStorage.getItem("quark.sel"); } catch {}
  app.sel = game(saved) ? saved : filtered()[0]?.id ?? null; app.open = app.cfg.view !== "grid";
  renderAll();
  invoke("list_runtimes").then((r) => (app.runtimes = r)).catch(() => (app.runtimes = []));
  if (app.cfg.auto_update) invoke("check_update").then((u) => { app.upd = u; renderTop(); }).catch(() => {});
  await listen("quark://session-started", (e) => { app.running.set(e.payload.id, { id: e.payload.id, elapsed: 0, at: Date.now(), label: e.payload.label }); renderList(); app.sel === e.payload.id && renderSheet(); });
  await listen("quark://session-stopping", (e) => { const r = app.running.get(e.payload.id); r && (r.stopping = true); app.sel === e.payload.id && renderSheet(); });
  await listen("quark://session-ended", (e) => {
    const { id, secs, game: g } = e.payload; app.running.delete(id); g && setGame(g);
    const n = game(id); n && toast(t("toast.stopped", { name: n.name }) + ` · ${hm(secs)}`); renderList(); app.sel === id && app.view === "library" && renderSheet();
  });
  setInterval(tick, 1000);
  setInterval(() => run(async () => { setRunning(await invoke("running_games")); renderList(); }), 15000);
}
boot().catch((e) => { document.body.textContent = String(e); });
