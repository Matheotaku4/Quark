"use strict";
// Navigation, bibliothèque (liste groupée / grille), fiche de jeu et accueil.

const NAV = [["home", "x.home"], ["store", "x.store"], ["mygames", "x.mygames"], ["library", "nav.library"]];
const ST_ORDER = ["playing", "backlog", "finished", "dropped", "none"];
const SORTS = { name: (a, b) => a.name.localeCompare(b.name, locale()), recent: (a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0), added: (a, b) => b.addedAt - a.addedAt,
  playtime: (a, b) => b.playtimeSecs - a.playtimeSecs, favorites: (a, b) => (b.favorite - a.favorite) || (b.lastPlayed || 0) - (a.lastPlayed || 0) };

function renderTop() {
  $("#top-tabs").innerHTML = NAV.map(([k, l]) => `<button data-view="${k}" class="${app.view === k ? "on" : ""}">${esc(t(l))}</button>`).join("");
  const grid = app.cfg.view === "grid", upd = app.upd && app.upd.newer;
  $("#top-right").innerHTML = `<button class="tb" data-act="toggle-view" title="${esc(t("x.view"))}">${ic(grid ? "list" : "grid")}</button>
    <button class="tb" data-act="add" title="${esc(t("x.add"))}">${ic("plus")}</button><button class="tb" data-act="palette" title="${esc(t("x.search"))}">${ic("search")}</button>
    <button class="tb" data-act="updates" title="${esc(t("x.updates"))}">${ic("down")}${upd ? '<i class="pip"></i>' : ""}</button>
    <button class="tb ${app.view === "settings" ? "on" : ""}" data-act="settings" title="${esc(t("settings.title"))}">${ic("gear")}</button><span class="vsep"></span>
    <button class="wb" data-win="win_minimize">${ic("min")}</button><button class="wb" data-win="win_toggle_maximize">${ic("max")}</button><button class="wb x" data-win="win_close">${ic("x")}</button>`;
  document.body.dataset.view = app.view; document.body.classList.toggle("grid", grid && app.view === "library");
}

// ---------- liste ----------
function filtered() {
  const q = norm(app.query.trim()), f = app.f;
  return app.data.games.filter((g) => (!f.status || g.status === f.status) && (!f.genre || g.genres.includes(f.genre)) && (!f.tag || g.tags.includes(f.tag)) && (!f.fav || g.favorite)
    && (!q || norm([g.name, g.developer, ...g.tags, ...g.genres].join(" ")).includes(q))).sort(SORTS[app.cfg.library_sort] || SORTS.name);
}
function groupOf(g) {
  switch (app.cfg.group_by) {
    case "status": return [g.status, t("status." + g.status)];
    case "store": return [g.sourceLabel || "Local", g.sourceLabel || t("source.local")];
    case "genre": return [g.genres[0] || "—", g.genres[0] || "—"];
    case "year": return [(g.released || "").slice(0, 4) || "—", (g.released || "").slice(0, 4) || "—"];
    default: return ["", ""];
  }
}
function row(g) {
  const live = app.running.has(g.id), art = g.iconUrl || g.coverUrl;
  const sub = live ? `<em data-live="${g.id}">${clock(elapsed(g.id))}</em>` : `${esc(rel(g.lastPlayed))} · ${hm(g.playtimeSecs)}`;
  return `<button class="row${g.id === app.sel ? " sel" : ""}${live ? " live" : ""}" data-id="${g.id}" style="${accent(g)}">
    <i class="ico">${art ? `<img src="${esc(art)}" alt="" loading="lazy">` : esc(g.monogram)}</i>
    <span class="meta"><b>${esc(g.name)}</b><small>${sub}</small></span>
    <i class="dot" style="background:${g.status === "none" ? "transparent" : g.statusColor}"></i></button>`;
}
function renderList() {
  const list = filtered(), by = app.cfg.group_by;
  if (by === "none") $("#list").innerHTML = list.map(row).join("");
  else {
    const m = new Map();
    for (const g of list) { const [k, l] = groupOf(g); (m.get(k) || m.set(k, { l, items: [], c: g.statusColor }).get(k)).items.push(g); }
    let keys = [...m.keys()];
    keys = by === "status" ? keys.sort((a, b) => ST_ORDER.indexOf(a) - ST_ORDER.indexOf(b)) : by === "year" ? keys.sort().reverse() : keys.sort((a, b) => a.localeCompare(b, locale()));
    $("#list").innerHTML = keys.map((k) => { const x = m.get(k), cl = app.collapsed.has(k);
      return `<h4 data-group="${esc(k)}" class="${cl ? "cl" : ""}">${ic("caret")}${by === "status" && k !== "none" ? `<i class="dot" style="background:${x.c}"></i>` : ""}<span>${esc(x.l)}</span><em>${x.items.length}</em></h4>${cl ? "" : x.items.map(row).join("")}`; }).join("");
  }
  if (!list.length) $("#list").innerHTML = `<div class="none">${esc(app.data.games.length ? t("list.empty") : t("list.emptyLibrary"))}</div>`;
  $("#count").textContent = t(list.length === 1 ? "library.countOne" : "library.countMany", { n: list.length });
  $("#lib-title").textContent = t("nav.library");
  const act = $(".row.sel", $("#list")); act && act.scrollIntoView({ block: "nearest" });
  $("#fl-btn").classList.toggle("on", !!(app.f.status || app.f.genre || app.f.tag || app.f.fav));
}
function renderSide() {
  $("#q").placeholder = t("search.library");
  const genres = [...new Set(app.data.games.flatMap((g) => g.genres))].sort(), tags = [...new Set(app.data.games.flatMap((g) => g.tags))].sort();
  $("#fl-pop").innerHTML = `<label>${esc(t("status.label"))}</label>${sel("f-status", [["", t("x.allStatuses")], ...ST_ORDER.map((s) => [s, t("status." + s)])], app.f.status)}
    <label>${esc(t("overview.genres"))}</label>${sel("f-genre", [["", t("x.allGenres")], ...genres.map((x) => [x, x])], app.f.genre)}
    <label>${esc(t("overview.tags"))}</label>${sel("f-tag", [["", t("x.allTags")], ...tags.map((x) => [x, x])], app.f.tag)}
    ${sw("f-fav", t("x.favOnly"), "", app.f.fav)}<button class="btn sec sm" data-act="reset-filters">${esc(t("x.reset"))}</button>`;
  $("#fl-label").textContent = t("x.filters");
  $("#sort").innerHTML = ["recent", "name", "playtime", "added", "favorites"].map((k) => `<option value="${k}" ${app.cfg.library_sort === k ? "selected" : ""}>${esc(k === "favorites" ? t("detail.favorite") : t("sort." + k))}</option>`).join("");
  $("#group").innerHTML = ["status", "store", "genre", "year", "none"].map((k) => `<option value="${k}" ${app.cfg.group_by === k ? "selected" : ""}>${esc(t("x.groupBy"))} · ${esc(({ status: t("status.label"), store: t("overview.source"), genre: t("overview.genres"), year: t("overview.released"), none: "—" })[k])}</option>`).join("");
}

// ---------- grille ----------
function renderGrid() {
  const list = filtered();
  return `<div class="gridwrap"><div class="grid" style="--tile:${Math.round(app.cfg.grid_tile_width || 170)}px">${list.map((g) => `<button class="tile${app.running.has(g.id) ? " live" : ""}" data-id="${g.id}" style="${accent(g)}">
    <div class="cover" style="${g.coverUrl ? `background-image:url('${esc(g.coverUrl)}')` : ""}">${g.coverUrl ? "" : `<b>${esc(g.monogram)}</b>`}${g.favorite ? `<span class="fav">${ic("star", "on")}</span>` : ""}</div>
    <span class="meta"><b>${esc(g.name)}</b><small>${hm(g.playtimeSecs)}</small></span></button>`).join("")}</div>${list.length ? "" : `<div class="none">${esc(t("list.empty"))}</div>`}</div>`;
}

// ---------- fiche de jeu ----------
const iconBtn = (act, icn, color, title, on) => `<button class="ib${on ? " on" : ""}" data-act="${act}" style="--c:${color}" title="${esc(title)}">${ic(icn, on ? "on" : "")}</button>`;
function renderGame(g) {
  const live = app.running.has(g.id), r = app.running.get(g.id), art = g.heroUrl || g.coverUrl;
  const sub = [g.developer, g.released, g.genres.slice(0, 3).join(", "), g.sourceLabel, g.isNative ? "Linux" : ""].filter(Boolean);
  const tabs = [["news", "x.news"], ["ach", "x.ach"], ["hist", "x.hist"]];
  const placement = app.cfg.game_actions === "beside_play";
  const actions = `<div class="acts">${iconBtn("fav", "star", "#ffc94d", t(g.favorite ? "detail.unfavorite" : "detail.favorite"), g.favorite)}${iconBtn("gsettings", "gear", "var(--accent)", t("x.settingsGame"))}${iconBtn("customize", "edit", "#ffc94d", t("x.customize"))}${iconBtn("log", "log", "#4cd07d", t("x.logBtn"))}${iconBtn("remove", "trash", "var(--danger)", t("x.remove"))}</div>`;
  return `<div class="gp" style="${accent(g)}">
    <div class="gh">
      <div class="gh-art" style="${art ? `background-image:url('${esc(art)}')` : ""}"></div><div class="gh-fade"></div>
      <div class="gh-top">${document.body.classList.contains("grid") ? `<button class="btn sec sm back" data-act="back">${ic("back")}${esc(t("x.back"))}</button>` : ""}<span id="pdb"></span><span class="sp"></span>${placement ? "" : actions}</div>
      <div class="gh-main">
        ${g.logoUrl ? `<img class="logo" src="${esc(g.logoUrl)}" alt="${esc(g.name)}">` : `<h1>${esc(g.name)}</h1>`}
        <div class="sub">${sub.map((s) => `<span>${esc(s)}</span>`).join("")}</div>
        <div class="act">
          <button class="play${live ? " run" : ""}" data-act="play">${ic(live ? "stop" : "play")}${esc(t(live ? (r.stopping ? "detail.stopping" : "detail.stop") : "detail.play"))}</button>
          <details class="menu st"><summary class="chip" style="--sc:${g.status === "none" ? "var(--text-faint)" : g.statusColor}"><i></i>${esc(t("status." + g.status))}</summary><div class="pop">${ST_ORDER.map((s) => `<button data-status="${s}">${esc(t("status." + s))}</button>`).join("")}</div></details>
          ${live ? `<span class="clock" data-live="${g.id}">${clock(elapsed(g.id))}</span>` : ""}${placement ? actions : ""}
        </div>
        ${g.exeMissing ? `<span class="warn">⚠ ${esc(t("detail.exeMissing"))}</span>` : ""}
      </div>
    </div>
    <div class="gb"><div class="gcol"><div class="tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${app.tab === k ? "on" : ""}">${esc(t(l))}</button>`).join("")}</div><div id="tabc"></div></div>
      <aside class="ov" id="ov"></aside></div></div>`;
}
function weeks(g) {
  const w = new Array(12).fill(0), now = Date.now() / 1000;
  for (const s of g.sessions) { const i = 11 - Math.floor((now - s.start) / 604800); if (i >= 0 && i < 12) w[i] += s.secs; }
  return w;
}
function renderOverview(g) {
  const live = app.running.has(g.id), row2 = (l, v) => (v ? `<div class="kv"><span>${esc(l)}</span><b>${v}</b></div>` : "");
  $("#ov").innerHTML = `<h3>${esc(t("x.overview"))}</h3>${row2(t("overview.playtime"), hm(g.playtimeSecs + (live ? elapsed(g.id) : 0)))}${row2(t("overview.lastPlayed"), esc(live ? t("detail.playingNow") : rel(g.lastPlayed)))}
    ${row2(t("x.sessions"), g.sessions.length)}${row2(t("overview.genres"), esc(g.genres.join(" · ")))}${row2(t("overview.developer"), esc(g.developer))}${row2(t("overview.released"), esc(g.released))}${row2(t("overview.source"), esc(g.sourceLabel))}
    <div class="hr"></div><div id="hltb"><h3 class="blue">HowLongToBeat</h3><div class="dim">…</div></div>`;
}
function renderTab(g) {
  const box = $("#tabc"); if (!box) return;
  if (app.tab === "news") return loadNews(g);
  if (app.tab === "ach") { box.innerHTML = `<div class="none"><b>${esc(t("x.soon"))}</b><br>${esc(t("x.soonBody"))}</div>`; return; }
  const w = weeks(g), max = Math.max(1, ...w), list = g.sessions.slice().reverse().slice(0, 40);
  box.innerHTML = `<div class="sec0"><h3>${esc(t("x.weeks"))}<span>${esc(hm(w[11]))}</span></h3><div class="bars">${w.map((v, i) => `<i class="${i === 11 ? "now " : ""}${v ? "v" : ""}" style="height:${Math.max(6, (v / max) * 100)}%" title="${hm(v)}"></i>`).join("")}</div></div>
    <div class="sec0"><h3>${esc(t("activity.recent"))}</h3>${list.length ? `<div class="sess">${list.map((s) => `<div><span>${date(s.start)}</span><span>${hm(s.secs)}</span></div>`).join("")}</div>` : `<div class="dim">${esc(t("activity.empty"))}</div>`}</div>`;
}
async function loadNews(g, force) {
  const box = $("#tabc"), c = (app.cache.news ||= {});
  if (!g.steamAppId) { box.innerHTML = `<div class="none">${esc(t("x.noAppId"))}</div>`; return; }
  if (!c[g.id] || force) { box.innerHTML = `<div class="none">${esc(t("log.loading"))}</div>`; c[g.id] = await invoke("fetch_news", { appId: g.steamAppId, count: 8 }).catch((e) => ({ err: String(e) })); }
  if (app.sel !== g.id || app.tab !== "news" || !$("#tabc")) return;
  const d = c[g.id];
  $("#tabc").innerHTML = `<div class="newshead"><h3>${esc(t("x.news"))}</h3><button class="btn sec sm" data-act="news-refresh">${ic("refresh")}${esc(t("x.refresh"))}</button></div>` +
    (d.err ? `<div class="none">${esc(d.err)}</div>` : d.length ? d.map((n, i) => `<details class="news"><summary><small>${esc(n.feed)}${n.author ? " · " + esc(n.author) : ""} · ${esc(rel(n.date))}</small><b>${esc(n.title)}</b><p>${esc(n.excerpt)}</p></summary>
      <div class="nbody">${esc(n.body)}</div><button class="btn sec sm" data-open="${esc(n.url)}">${ic("ext")}${esc(n.url ? "Steam" : "")}</button></details>`).join("") : `<div class="none">${esc(t("x.noNews"))}</div>`);
}
async function loadExtras(g) {
  const c = (app.cache.hltb ||= {}), p = (app.cache.pdb ||= {});
  if (!(g.id in c)) c[g.id] = await invoke("fetch_hltb", { title: g.name }).catch(() => null);
  if (g.steamAppId && !(g.id in p)) p[g.id] = await invoke("fetch_protondb", { appId: g.steamAppId }).catch(() => null);
  if (app.sel !== g.id) return;
  const h = c[g.id], box = $("#hltb"), d = p[g.id], b = $("#pdb");
  if (box) box.innerHTML = `<h3 class="blue">HowLongToBeat</h3>${h ? `<div class="kv"><span>${esc(t("x.main"))}</span><b>${hrs(h.main)}</b></div><div class="kv"><span>${esc(t("x.extra"))}</span><b>${hrs(h.mainExtra)}</b></div><div class="kv"><span>${esc(t("x.compl"))}</span><b>${hrs(h.completionist)}</b></div><button class="lnk" data-open="${esc(h.url)}">${esc(t("x.hltbLink"))} →</button>` : `<div class="dim">—</div>`}`;
  if (b && d) b.innerHTML = `<span class="badge" style="--bc:${d.color}" title="${esc(d.label)}">${esc(d.tier)} · ProtonDB</span>`;
}

// ---------- accueil ----------
function renderHome() {
  const games = app.data.games.slice().sort(SORTS[app.cfg.home_sort] || SORTS.recent), list = games.filter((g) => g.heroUrl || g.coverUrl).slice(0, 6), n = list.length;
  app.hi = n ? (app.hi || 0) % n : 0; const g = list[app.hi] || games[0];
  if (!g) return `<div class="empty"><h2>${esc(t("empty.title"))}</h2><p>${esc(t("empty.subtitle"))}</p><button class="btn" data-act="add">${esc(t("empty.add"))}</button></div>`;
  const rail = (title, items) => (items.length ? `<section class="rail"><h3>${esc(title)}</h3><div class="cards">${items.slice(0, 12).map((x) => `<button class="tile sm" data-id="${x.id}" data-go="library" style="${accent(x)}"><div class="cover" style="${x.coverUrl ? `background-image:url('${esc(x.coverUrl)}')` : ""}">${x.coverUrl ? "" : `<b>${esc(x.monogram)}</b>`}</div><span class="meta"><b>${esc(x.name)}</b><small>${hm(x.playtimeSecs)}</small></span></button>`).join("")}</div></section>` : "");
  const by = (f) => games.filter(f);
  return `<div class="home"><div class="gh big" style="${accent(g)}"><div class="gh-art" style="background-image:url('${esc(g.heroUrl || g.coverUrl || "")}')"></div><div class="gh-fade"></div>
    <div class="gh-main">${g.logoUrl ? `<img class="logo" src="${esc(g.logoUrl)}" alt="">` : `<h1>${esc(g.name)}</h1>`}<div class="sub"><span>${esc(rel(g.lastPlayed))}</span><span>${hm(g.playtimeSecs)}</span></div>
      <div class="act"><button class="play" data-id="${g.id}" data-go="library" data-launch="1">${ic("play")}${esc(t("detail.play"))}</button><button class="btn sec" data-id="${g.id}" data-go="library">${esc(t("x.overview"))}</button></div></div>
    ${n > 1 ? `<div class="dots">${list.map((_, i) => `<button data-hi="${i}" class="${i === app.hi ? "on" : ""}"></button>`).join("")}</div>` : ""}</div>
    ${rail(t("x.continue"), by((x) => x.lastPlayed).sort(SORTS.recent))}${rail(t("x.favorites"), by((x) => x.favorite))}${rail(t("x.backlog"), by((x) => x.status === "backlog"))}</div>`;
}
const renderSoon = (name) => `<div class="empty"><h2>${esc(name)}</h2><p>${esc(t("x.soonBody"))}</p></div>`;

// ---------- orchestration ----------
function renderSheet() {
  const el = $("#sheet"), v = app.view;
  if (v === "settings") { el.innerHTML = renderSettings(); bindSettings(); return; }
  if (v === "home") { el.innerHTML = renderHome(); return; }
  if (v === "store") { el.innerHTML = renderStore(); bindStore(); storeEnter(); return; }
  if (v === "mygames") { el.innerHTML = renderSoon(t("x.mygames")); return; }
  if (document.body.classList.contains("grid") && !app.open) { el.innerHTML = renderGrid(); return; }
  const g = game(app.sel);
  if (!g) { el.innerHTML = `<div class="empty"><h2>${esc(t("empty.title"))}</h2><p>${esc(t("empty.subtitle"))}</p><button class="btn" data-act="add">${esc(t("empty.add"))}</button></div>`; return; }
  el.innerHTML = renderGame(g); renderOverview(g); renderTab(g); loadExtras(g);
}
function renderAll() { renderTop(); renderSide(); renderList(); renderSheet(); }
function select(id) { app.sel = id; app.open = true; try { localStorage.setItem("quark.sel", id); } catch {} renderList(); renderSheet(); $("#sheet").scrollTop = 0; }
function setView(v) { app.view = v; renderAll(); $("#sheet").scrollTop = 0; }
