//! Interface Tauri de Quark.
//!
//! Le cœur métier (configuration, Proton, sessions, boutiques) est celui de
//! `quark` : cette couche ne fait que l'exposer à une interface web locale.
//! Aucun réseau n'est nécessaire au rendu ; les images d'artwork passent par
//! le protocole local `quarkimg://`.

mod features;
mod store;
mod themes;

use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine as _;
use quark::config::{
    self, AssetKind, Game, GameStatus, Library, PlaySession, ProtonMode, Settings, ThemeMode,
    UiLanguage,
};
use quark::proton::{self, ProtonRuntime};
use quark::providers;
use quark::session::{self, Session};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, MutexGuard};
use std::time::Duration;
use tauri::http::{header, Response, StatusCode};
use tauri::{AppHandle, Emitter, Manager, RunEvent, State};
use themes::THEMES;

// ---------------------------------------------------------------------------
// État partagé
// ---------------------------------------------------------------------------

struct Running {
    session: Session,
    started_ts: i64,
    label: String,
    name: String,
}

struct AppState {
    library: Mutex<Library>,
    sessions: Mutex<HashMap<String, Running>>,
    runtimes: Vec<ProtonRuntime>,
    demo: bool,
    demo_root: Option<PathBuf>,
}

fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex.lock().unwrap_or_else(|poison| poison.into_inner())
}

// ---------------------------------------------------------------------------
// Objets envoyés à l'interface
// ---------------------------------------------------------------------------

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct GameDto {
    id: String,
    name: String,
    exe: String,
    args: String,
    status: String,
    status_color: String,
    favorite: bool,
    tags: Vec<String>,
    developer: String,
    genres: Vec<String>,
    released: String,
    description: String,
    notes: String,
    playtime_secs: u64,
    last_played: Option<i64>,
    added_at: i64,
    steam_app_id: Option<u32>,
    provider: String,
    source_label: String,
    is_native: bool,
    exe_missing: bool,
    installed: bool,
    installations: Vec<InstallationDto>,
    cover_url: Option<String>,
    hero_url: Option<String>,
    logo_url: Option<String>,
    icon_url: Option<String>,
    monogram: String,
    hue: u16,
    proton: String,
    umu: bool,
    anticheat: String,
    prefix: String,
    launch: LaunchDto,
    env: Vec<EnvDto>,
    sessions: Vec<SessionDto>,
    running: bool,
    running_label: Option<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct InstallationDto {
    id: String,
    label: String,
    source: String,
    exe: String,
    path: Option<String>,
    installed: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct LaunchDto {
    gamemode: bool,
    mangohud: bool,
    gamescope: bool,
    gamescope_width: u32,
    gamescope_height: u32,
    gamescope_fsr: bool,
    gamescope_fps: u32,
    prime: bool,
    wrapper: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct EnvDto {
    name: String,
    value: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SessionDto {
    start: i64,
    secs: u64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SettingsDto {
    theme: String,
    ui_language: String,
    compact: bool,
    hero_background: bool,
    start_page: String,
    view: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ThemeDto {
    id: &'static str,
    label: &'static str,
    vars: ThemeVars,
}

#[derive(Serialize)]
struct ThemeVars {
    bg: &'static str,
    panel: &'static str,
    surface: &'static str,
    #[serde(rename = "surface-hover")]
    surface_hover: &'static str,
    border: &'static str,
    #[serde(rename = "row-selected")]
    row_selected: &'static str,
    text: &'static str,
    #[serde(rename = "text-dim")]
    text_dim: &'static str,
    #[serde(rename = "text-faint")]
    text_faint: &'static str,
    accent: &'static str,
    #[serde(rename = "accent-hover")]
    accent_hover: &'static str,
    #[serde(rename = "accent-pressed")]
    accent_pressed: &'static str,
    danger: &'static str,
    header: &'static str,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct StatusDto {
    id: String,
    color: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct LanguageDto {
    id: String,
    label: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct RunningDto {
    id: String,
    name: String,
    label: String,
    elapsed: u64,
    stopping: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Bootstrap {
    games: Vec<GameDto>,
    settings: SettingsDto,
    themes: Vec<ThemeDto>,
    statuses: Vec<StatusDto>,
    languages: Vec<LanguageDto>,
    running: Vec<RunningDto>,
    config_path: String,
    data_dir: String,
    version: String,
    memory_mb: Option<u64>,
    demo: bool,
    load_error: Option<String>,
}

// ---------------------------------------------------------------------------
// Conversions
// ---------------------------------------------------------------------------

fn snake<T: Serialize>(value: &T) -> String {
    serde_json::to_value(value)
        .ok()
        .and_then(|value| value.as_str().map(str::to_owned))
        .unwrap_or_default()
}

fn hue_for(name: &str) -> u16 {
    let mut hash: u32 = 2_166_136_261;
    for byte in name.bytes() {
        hash ^= u32::from(byte);
        hash = hash.wrapping_mul(16_777_619);
    }
    (hash % 360) as u16
}

fn asset_url(path: Option<&PathBuf>) -> Option<String> {
    let path = path?;
    if !path.is_file() {
        return None;
    }
    let encoded = URL_SAFE_NO_PAD.encode(path.to_string_lossy().as_bytes());
    Some(format!("quarkimg://localhost/{encoded}"))
}

fn proton_label(mode: &ProtonMode) -> String {
    match mode {
        ProtonMode::Default => "Auto".to_string(),
        ProtonMode::Native => "Natif".to_string(),
        ProtonMode::Runtime(key) => key.clone(),
    }
}

fn game_dto(
    game: &Game,
    settings: &Settings,
    running: bool,
    running_label: Option<String>,
) -> GameDto {
    let active = game.active_installation();
    let provider = active
        .and_then(|installation| installation.provider)
        .map(|provider| snake(&provider))
        .unwrap_or_else(|| "local".to_string());
    let source_label = active
        .map(|installation| installation.source_label().to_string())
        .unwrap_or_else(|| "Locale".to_string());
    let status_color = game.status.color();
    let installations = game
        .installations
        .iter()
        .map(|installation| InstallationDto {
            id: installation.id.clone(),
            label: installation.label.clone(),
            source: installation.source_label().to_string(),
            exe: installation.exe.clone(),
            path: installation.path.clone(),
            installed: installation.installed,
        })
        .collect::<Vec<_>>();
    let installed = game
        .installations
        .iter()
        .any(|installation| installation.installed)
        || !game.exe_missing();
    let mut sessions = game.sessions.clone();
    sessions.sort_by_key(|session| std::cmp::Reverse(session.start));
    let sessions = sessions
        .iter()
        .take(120)
        .map(|session| SessionDto {
            start: session.start,
            secs: session.secs,
        })
        .collect::<Vec<_>>();
    GameDto {
        id: game.id.clone(),
        name: game.name.clone(),
        exe: game.exe.clone(),
        args: game.args.clone(),
        status: snake(&game.status),
        status_color: format!(
            "#{:02x}{:02x}{:02x}",
            status_color.0, status_color.1, status_color.2
        ),
        favorite: game.favorite,
        tags: game.tags.clone(),
        developer: game.developer.clone(),
        genres: game.genres.clone(),
        released: game.released.clone(),
        description: game.description.clone(),
        notes: game.notes.clone(),
        playtime_secs: game.playtime_secs,
        last_played: game.last_played,
        added_at: game.added_at,
        steam_app_id: game.steam_app_id,
        provider,
        source_label,
        is_native: game.is_native(),
        exe_missing: game.exe_missing(),
        installed,
        installations,
        cover_url: asset_url(game.artwork.cover.as_ref()),
        hero_url: asset_url(game.artwork.hero.as_ref()),
        logo_url: asset_url(game.artwork.logo.as_ref()),
        icon_url: asset_url(game.artwork.icon.as_ref()),
        monogram: game.monogram_letter(),
        hue: hue_for(&game.name),
        proton: proton_label(&game.proton),
        umu: game.umu,
        anticheat: snake(&game.anticheat),
        prefix: game.prefix_path(settings).display().to_string(),
        launch: LaunchDto {
            gamemode: game.launch.gamemode,
            mangohud: game.launch.mangohud,
            gamescope: game.launch.gamescope,
            gamescope_width: game.launch.gamescope_width,
            gamescope_height: game.launch.gamescope_height,
            gamescope_fsr: game.launch.gamescope_fsr,
            gamescope_fps: game.launch.gamescope_fps,
            prime: game.launch.prime,
            wrapper: game.launch.wrapper.clone(),
        },
        env: game
            .env
            .iter()
            .map(|variable| EnvDto {
                name: variable.name.clone(),
                value: variable.value.clone(),
            })
            .collect(),
        sessions,
        running,
        running_label,
    }
}

fn settings_dto(settings: &Settings) -> SettingsDto {
    SettingsDto {
        theme: snake(&settings.theme),
        ui_language: snake(&settings.ui_language),
        compact: settings.ui_compact,
        hero_background: settings.hero_background,
        start_page: snake(&settings.start_page),
        view: snake(&settings.view),
    }
}

fn theme_dtos() -> Vec<ThemeDto> {
    THEMES
        .iter()
        .map(|theme| ThemeDto {
            id: theme.id,
            label: theme.label,
            vars: ThemeVars {
                bg: theme.bg,
                panel: theme.panel,
                surface: theme.surface,
                surface_hover: theme.surface_hover,
                border: theme.border,
                row_selected: theme.row_selected,
                text: theme.text,
                text_dim: theme.text_dim,
                text_faint: theme.text_faint,
                accent: theme.accent,
                accent_hover: theme.accent_hover,
                accent_pressed: theme.accent_pressed,
                danger: theme.danger,
                header: theme.header,
            },
        })
        .collect()
}

fn running_dtos(state: &AppState) -> Vec<RunningDto> {
    lock(&state.sessions)
        .iter()
        .map(|(id, run)| RunningDto {
            id: id.clone(),
            name: run.name.clone(),
            label: run.label.clone(),
            elapsed: run.session.started.elapsed().as_secs(),
            stopping: run.session.stopping.is_some(),
        })
        .collect()
}

fn bootstrap(state: &AppState) -> Bootstrap {
    let library = lock(&state.library);
    let settings = library.settings.clone();
    let running = running_dtos(state);
    let running_map: HashMap<&str, &RunningDto> =
        running.iter().map(|run| (run.id.as_str(), run)).collect();
    let games = library
        .games
        .iter()
        .map(|game| {
            let run = running_map.get(game.id.as_str());
            game_dto(
                game,
                &settings,
                run.is_some(),
                run.map(|run| run.label.clone()),
            )
        })
        .collect();
    Bootstrap {
        games,
        settings: settings_dto(&settings),
        themes: theme_dtos(),
        statuses: GameStatus::ALL
            .iter()
            .map(|status| {
                let color = status.color();
                StatusDto {
                    id: snake(status),
                    color: format!("#{:02x}{:02x}{:02x}", color.0, color.1, color.2),
                }
            })
            .collect(),
        languages: UiLanguage::ALL
            .iter()
            .map(|language| LanguageDto {
                id: snake(language),
                label: language.label(),
            })
            .collect(),
        running,
        config_path: config::config_dir().display().to_string(),
        data_dir: config::data_dir().display().to_string(),
        version: env!("CARGO_PKG_VERSION").to_string(),
        memory_mb: config::resident_mb(),
        demo: state.demo,
        load_error: library.load_error.clone(),
    }
}

fn persist(state: &AppState, library: &mut Library) -> Result<(), String> {
    if state.demo {
        return Ok(());
    }
    library.save()
}

fn parse_language(value: &str) -> Option<UiLanguage> {
    match value.trim().to_ascii_lowercase().as_str() {
        "french" | "fr" => Some(UiLanguage::French),
        "english" | "en" => Some(UiLanguage::English),
        "spanish" | "es" => Some(UiLanguage::Spanish),
        "german" | "de" => Some(UiLanguage::German),
        "portuguese" | "pt" => Some(UiLanguage::Portuguese),
        _ => None,
    }
}

fn parse_theme(value: &str) -> Option<ThemeMode> {
    serde_json::from_value(serde_json::Value::String(value.to_string())).ok()
}

fn parse_status(value: &str) -> Option<GameStatus> {
    serde_json::from_value(serde_json::Value::String(value.to_string())).ok()
}

// ---------------------------------------------------------------------------
// Commandes
// ---------------------------------------------------------------------------

#[tauri::command]
fn bootstrap_data(state: State<'_, AppState>) -> Bootstrap {
    bootstrap(&state)
}

#[tauri::command]
fn running_games(state: State<'_, AppState>) -> Vec<RunningDto> {
    running_dtos(&state)
}

#[tauri::command]
fn get_game(state: State<'_, AppState>, id: String) -> Result<GameDto, String> {
    let library = lock(&state.library);
    let settings = library.settings.clone();
    let game = library
        .get(&id)
        .ok_or_else(|| "Jeu introuvable".to_string())?;
    let sessions = lock(&state.sessions);
    let run = sessions.get(&id);
    Ok(game_dto(
        game,
        &settings,
        run.is_some(),
        run.map(|run| run.label.clone()),
    ))
}

#[tauri::command]
fn launch_game(app: AppHandle, state: State<'_, AppState>, id: String) -> Result<GameDto, String> {
    if state.demo {
        return Err("Le lancement est désactivé en mode démonstration.".to_string());
    }
    if lock(&state.sessions).contains_key(&id) {
        return Err("Ce jeu est déjà en cours.".to_string());
    }
    let (mut game, settings) = {
        let library = lock(&state.library);
        (
            library
                .get(&id)
                .cloned()
                .ok_or_else(|| "Jeu introuvable".to_string())?,
            library.settings.clone(),
        )
    };
    game.normalize_installations();
    if game.exe_missing() {
        return Err(format!(
            "{} : exécutable introuvable ({}).",
            game.name,
            if game.exe.trim().is_empty() {
                "aucun chemin défini".to_string()
            } else {
                game.exe.clone()
            }
        ));
    }
    let resolved =
        proton::resolve_with(&game, &settings, &state.runtimes, proton::Tools::detect())?;
    if let Some(prefix) = &resolved.prefix {
        std::fs::create_dir_all(prefix).map_err(|error| format!("Préfixe Proton : {error}"))?;
    }
    let diagnostics =
        providers::connection_diagnostics(None, Some(&game.wine_prefix_path(&settings)));
    let session = session::start(&game, &resolved, &diagnostics)?;
    let label = resolved.label();
    lock(&state.sessions).insert(
        id.clone(),
        Running {
            session,
            started_ts: config::now_ts(),
            label: label.clone(),
            name: game.name.clone(),
        },
    );
    let _ = app.emit(
        "quark://session-started",
        serde_json::json!({ "id": id, "label": label }),
    );
    get_game(state, id)
}

#[tauri::command]
fn stop_game(app: AppHandle, state: State<'_, AppState>, id: String) -> Result<RunningDto, String> {
    let mut sessions = lock(&state.sessions);
    let run = sessions
        .get_mut(&id)
        .ok_or_else(|| "Ce jeu n'est pas en cours.".to_string())?;
    session::stop(&mut run.session);
    let dto = RunningDto {
        id: id.clone(),
        name: run.name.clone(),
        label: run.label.clone(),
        elapsed: run.session.started.elapsed().as_secs(),
        stopping: run.session.stopping.is_some(),
    };
    drop(sessions);
    let _ = app.emit("quark://session-stopping", serde_json::json!({ "id": id }));
    Ok(dto)
}

#[tauri::command]
fn set_favorite(state: State<'_, AppState>, id: String, favorite: bool) -> Result<GameDto, String> {
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        game.favorite = favorite;
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn set_status(state: State<'_, AppState>, id: String, status: String) -> Result<GameDto, String> {
    let status = parse_status(&status).ok_or_else(|| "Statut inconnu".to_string())?;
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        game.status = status;
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn set_notes(state: State<'_, AppState>, id: String, notes: String) -> Result<(), String> {
    let mut library = lock(&state.library);
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        game.notes = notes;
    }
    persist(&state, &mut library)
}

#[tauri::command]
fn add_tag(state: State<'_, AppState>, id: String, tag: String) -> Result<GameDto, String> {
    let tag = tag.trim().to_string();
    if tag.is_empty() {
        return Err("Tag vide".to_string());
    }
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        if !game
            .tags
            .iter()
            .any(|existing| existing.eq_ignore_ascii_case(&tag))
        {
            game.tags.push(tag);
        }
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn remove_tag(state: State<'_, AppState>, id: String, tag: String) -> Result<GameDto, String> {
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        game.tags.retain(|existing| existing != &tag);
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn update_game(
    state: State<'_, AppState>,
    id: String,
    name: Option<String>,
    exe: Option<String>,
    args: Option<String>,
) -> Result<GameDto, String> {
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        if let Some(name) = name {
            let name = name.trim().to_string();
            if !name.is_empty() {
                game.name = name;
            }
        }
        if let Some(exe) = exe {
            let exe = exe.trim().to_string();
            if !exe.is_empty() {
                game.exe = exe;
            }
        }
        if let Some(args) = args {
            game.args = args;
        }
        game.normalize_installations();
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn add_game(state: State<'_, AppState>, name: String, exe: String) -> Result<GameDto, String> {
    let exe = exe.trim().to_string();
    if exe.is_empty() {
        return Err("Choisissez un exécutable.".to_string());
    }
    let name = if name.trim().is_empty() {
        Path::new(&exe)
            .file_stem()
            .map(|stem| stem.to_string_lossy().into_owned())
            .unwrap_or_else(|| "Nouveau jeu".to_string())
    } else {
        name.trim().to_string()
    };
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    let mut game = Game::new(name, exe);
    game.args = settings.default_args.clone();
    game.proton = settings
        .default_proton
        .clone()
        .map(ProtonMode::Runtime)
        .unwrap_or_default();
    game.prefix = settings.default_prefix.clone();
    game.anticheat = settings.default_anticheat;
    game.launch = settings.default_launch.clone();
    game.umu = settings.default_umu;
    game.proton_log = settings.default_proton_log;
    game.env = settings.default_env.clone();
    game.normalize_installations();
    let id = game.id.clone();
    library.games.push(game);
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

#[tauri::command]
fn remove_game(state: State<'_, AppState>, id: String) -> Result<(), String> {
    if lock(&state.sessions).contains_key(&id) {
        return Err("Arrêtez le jeu avant de le retirer.".to_string());
    }
    let mut library = lock(&state.library);
    library.games.retain(|game| game.id != id);
    persist(&state, &mut library)
}

#[tauri::command]
fn open_folder(state: State<'_, AppState>, id: String) -> Result<(), String> {
    let library = lock(&state.library);
    let game = library
        .get(&id)
        .ok_or_else(|| "Jeu introuvable".to_string())?;
    let directory = game
        .exe_path()
        .parent()
        .filter(|path| path.is_dir())
        .map(Path::to_path_buf)
        .or_else(|| {
            game.active_installation()
                .and_then(|installation| installation.path.as_deref())
                .map(PathBuf::from)
                .filter(|path| path.is_dir())
        })
        .ok_or_else(|| "Dossier introuvable.".to_string())?;
    session::open_folder(&directory)
}

#[tauri::command]
fn open_config_folder() -> Result<(), String> {
    session::open_folder(&config::config_dir())
}

#[tauri::command]
fn read_log(state: State<'_, AppState>, id: String) -> Result<String, String> {
    let library = lock(&state.library);
    let game = library
        .get(&id)
        .ok_or_else(|| "Jeu introuvable".to_string())?;
    let (lines, truncated) = session::read_log_tail(&config::session_log(&game.id), 240)?;
    let mut text = String::new();
    if truncated {
        text.push_str("…\n");
    }
    text.push_str(&lines.join("\n"));
    Ok(text)
}

#[derive(Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
struct SettingsPatch {
    theme: Option<String>,
    ui_language: Option<String>,
    compact: Option<bool>,
    hero_background: Option<bool>,
    start_page: Option<String>,
    view: Option<String>,
}

#[tauri::command]
fn save_settings(state: State<'_, AppState>, patch: SettingsPatch) -> Result<SettingsDto, String> {
    let mut library = lock(&state.library);
    {
        let settings = &mut library.settings;
        if let Some(theme) = patch.theme {
            settings.theme = parse_theme(&theme).ok_or_else(|| "Thème inconnu".to_string())?;
        }
        if let Some(language) = patch.ui_language {
            let language =
                parse_language(&language).ok_or_else(|| "Langue inconnue".to_string())?;
            settings.ui_language = language;
            quark::i18n::set_language(language);
        }
        if let Some(compact) = patch.compact {
            settings.ui_compact = compact;
        }
        if let Some(hero) = patch.hero_background {
            settings.hero_background = hero;
        }
        if let Some(start_page) = patch.start_page {
            settings.start_page = serde_json::from_value(serde_json::Value::String(start_page))
                .map_err(|_| "Page de démarrage inconnue".to_string())?;
        }
        if let Some(view) = patch.view {
            settings.view = serde_json::from_value(serde_json::Value::String(view))
                .map_err(|_| "Vue inconnue".to_string())?;
        }
    }
    let dto = settings_dto(&library.settings);
    persist(&state, &mut library)?;
    Ok(dto)
}

#[tauri::command]
fn reload_library(state: State<'_, AppState>) -> Result<Bootstrap, String> {
    if state.demo {
        return Ok(bootstrap(&state));
    }
    let library = Library::load();
    quark::i18n::set_language(library.settings.ui_language);
    *lock(&state.library) = library;
    Ok(bootstrap(&state))
}

#[tauri::command]
async fn pick_executable() -> Option<String> {
    tauri::async_runtime::spawn_blocking(|| {
        rfd::FileDialog::new()
            .set_title("Choisir l'exécutable du jeu")
            .pick_file()
            .map(|path| path.display().to_string())
    })
    .await
    .ok()
    .flatten()
}

#[tauri::command]
async fn pick_artwork(app: AppHandle, id: String, kind: String) -> Result<GameDto, String> {
    let path = tauri::async_runtime::spawn_blocking(|| {
        rfd::FileDialog::new()
            .set_title("Choisir une image")
            .add_filter("Images", &["png", "jpg", "jpeg", "webp"])
            .pick_file()
    })
    .await
    .map_err(|error| error.to_string())?
    .ok_or_else(|| "Aucune image choisie.".to_string())?;
    let kind = match kind.as_str() {
        "cover" => AssetKind::Cover,
        "hero" => AssetKind::Hero,
        "logo" => AssetKind::Logo,
        "icon" => AssetKind::Icon,
        _ => return Err("Type d'image inconnu.".to_string()),
    };
    let state = app.state::<AppState>();
    let mut library = lock(&state.library);
    let settings = library.settings.clone();
    let game_id = library
        .get(&id)
        .ok_or_else(|| "Jeu introuvable".to_string())?
        .id
        .clone();
    let directory = config::artwork_root().join(&game_id);
    let imported = quark::artwork::import_file(&path, &directory, kind)?;
    {
        let game = library
            .get_mut(&id)
            .ok_or_else(|| "Jeu introuvable".to_string())?;
        game.artwork.set(kind, imported);
    }
    persist(&state, &mut library)?;
    Ok(game_dto(library.get(&id).unwrap(), &settings, false, None))
}

// ---------------------------------------------------------------------------
// Fenêtre sans décorations natives
// ---------------------------------------------------------------------------

#[tauri::command]
fn win_minimize(window: tauri::Window) {
    let _ = window.minimize();
}

#[tauri::command]
fn win_toggle_maximize(window: tauri::Window) {
    if window.is_maximized().unwrap_or(false) {
        let _ = window.unmaximize();
    } else {
        let _ = window.maximize();
    }
}

#[tauri::command]
fn win_close(window: tauri::Window) {
    let _ = window.close();
}

#[tauri::command]
fn win_start_drag(window: tauri::Window) {
    let _ = window.start_dragging();
}

#[tauri::command]
fn win_start_resize(window: tauri::Window, direction: String) {
    use tauri_runtime::ResizeDirection;
    let direction = match direction.as_str() {
        "e" => ResizeDirection::East,
        "n" => ResizeDirection::North,
        "ne" => ResizeDirection::NorthEast,
        "nw" => ResizeDirection::NorthWest,
        "s" => ResizeDirection::South,
        "se" => ResizeDirection::SouthEast,
        "sw" => ResizeDirection::SouthWest,
        "w" => ResizeDirection::West,
        _ => return,
    };
    let _ = window.start_resize_dragging(direction);
}

// ---------------------------------------------------------------------------
// Protocole d'images local
// ---------------------------------------------------------------------------

fn serve_asset(state: &AppState, request: tauri::http::Request<Vec<u8>>) -> Response<Vec<u8>> {
    let encoded = request.uri().path().trim_start_matches('/');
    let Ok(bytes) = URL_SAFE_NO_PAD.decode(encoded) else {
        return Response::builder()
            .status(StatusCode::BAD_REQUEST)
            .body(Vec::new())
            .unwrap();
    };
    let Ok(text) = String::from_utf8(bytes) else {
        return Response::builder()
            .status(StatusCode::BAD_REQUEST)
            .body(Vec::new())
            .unwrap();
    };
    let path = PathBuf::from(text);
    let Some(canonical) = std::fs::canonicalize(&path).ok() else {
        return Response::builder()
            .status(StatusCode::NOT_FOUND)
            .body(Vec::new())
            .unwrap();
    };
    let allowed = std::fs::canonicalize(config::artwork_root())
        .ok()
        .is_some_and(|root| canonical.starts_with(root))
        || state
            .demo_root
            .as_ref()
            .and_then(|root| std::fs::canonicalize(root).ok())
            .is_some_and(|root| canonical.starts_with(root));
    if !allowed {
        return Response::builder()
            .status(StatusCode::FORBIDDEN)
            .body(Vec::new())
            .unwrap();
    }
    let Ok(data) = std::fs::read(&canonical) else {
        return Response::builder()
            .status(StatusCode::NOT_FOUND)
            .body(Vec::new())
            .unwrap();
    };
    let mime = match canonical
        .extension()
        .and_then(|extension| extension.to_str())
        .unwrap_or_default()
        .to_ascii_lowercase()
        .as_str()
    {
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "webp" => "image/webp",
        "gif" => "image/gif",
        "svg" => "image/svg+xml",
        _ => "application/octet-stream",
    };
    Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, mime)
        .header(header::CACHE_CONTROL, "no-cache")
        .body(data)
        .unwrap()
}

// ---------------------------------------------------------------------------
// Démonstration (captures, revue de l'interface)
// ---------------------------------------------------------------------------

struct DemoSpec {
    name: &'static str,
    developer: &'static str,
    genres: &'static [&'static str],
    released: &'static str,
    description: &'static str,
    status: GameStatus,
    favorite: bool,
    hours: f32,
    days_ago: i64,
    tags: &'static [&'static str],
    notes: &'static str,
}

const DEMO: &[DemoSpec] = &[
    DemoSpec {
        name: "Hollow Knight",
        developer: "Team Cherry",
        genres: &["Metroidvania", "Action", "Aventure"],
        released: "24 février 2017",
        description: "Descendez dans les ruines de Hallownest, un royaume souterrain rongé par un mal ancien. Explorez des galeries interconnectées, affrontez des gardiens oubliés et découvrez pourquoi tant de voyageurs ont été appelés sous terre.",
        status: GameStatus::Playing,
        favorite: true,
        hours: 42.5,
        days_ago: 1,
        tags: &["coop", "exploration", "difficile"],
        notes: "Reprendre au Colisée des Fous. Il reste deux masques à trouver dans les Jardins de la Reine.",
    },
    DemoSpec {
        name: "Celeste",
        developer: "Extremely OK Games",
        genres: &["Plateforme", "Précision"],
        released: "25 janvier 2018",
        description: "Aidez Madeline à gravir la montagne Celeste. Un jeu de plateforme exigeant sur le geste, porté par une bande-son de Lena Raine et un récit sur l'anxiété et la persévérance.",
        status: GameStatus::Finished,
        favorite: true,
        hours: 18.0,
        days_ago: 26,
        tags: &["difficile", "speedrun"],
        notes: "Face B terminée. Il reste les fraises dorées.",
    },
    DemoSpec {
        name: "Hades",
        developer: "Supergiant Games",
        genres: &["Roguelike", "Action", "Narratif"],
        released: "17 septembre 2020",
        description: "Fuyez les Enfers encore et encore. Chaque tentative fait avancer l'histoire, débloque de nouvelles armes et resserre les liens avec les dieux de l'Olympe.",
        status: GameStatus::Playing,
        favorite: false,
        hours: 31.2,
        days_ago: 3,
        tags: &["roguelike", "manette"],
        notes: "",
    },
    DemoSpec {
        name: "Disco Elysium",
        developer: "ZA/UM",
        genres: &["RPG", "Narratif", "Enquête"],
        released: "15 octobre 2019",
        description: "Un détective amnésique se réveille dans une ville au bord de l'effondrement. Faites parler les voix de son esprit, menez l'enquête et décidez de ce qu'il reste de lui.",
        status: GameStatus::Backlog,
        favorite: true,
        hours: 0.0,
        days_ago: 0,
        tags: &["histoire", "à commencer"],
        notes: "À lancer quand j'aurai une soirée calme devant moi.",
    },
    DemoSpec {
        name: "Outer Wilds",
        developer: "Mobius Digital",
        genres: &["Aventure", "Exploration", "Mystère"],
        released: "28 mai 2019",
        description: "Votre système solaire tourne en boucle depuis 22 minutes. Explorez des planètes vivantes, lisez les traces d'une civilisation disparue et comprenez ce qui se répète.",
        status: GameStatus::Finished,
        favorite: true,
        hours: 22.4,
        days_ago: 64,
        tags: &["exploration", "sans spoiler"],
        notes: "Ne rien lire avant de l'avoir fini. Le DLC reste à faire.",
    },
    DemoSpec {
        name: "Factorio",
        developer: "Wube Software",
        genres: &["Simulation", "Stratégie", "Automatisation"],
        released: "14 août 2020",
        description: "Construisez une usine toujours plus grande sur une planète hostile. Extraire, transformer, transporter, automatiser — puis recommencer, en plus grand.",
        status: GameStatus::Playing,
        favorite: false,
        hours: 128.6,
        days_ago: 2,
        tags: &["base", "long terme"],
        notes: "Base principale : 1 200 spm. Passer au nucléaire.",
    },
    DemoSpec {
        name: "Stardew Valley",
        developer: "ConcernedApe",
        genres: &["Simulation", "Gestion", "Détente"],
        released: "26 février 2016",
        description: "Reprenez la ferme de votre grand-père. Cultivez, pêchez, explorez les mines et apprenez à connaître les habitants de la vallée, au rythme des saisons.",
        status: GameStatus::Playing,
        favorite: false,
        hours: 76.1,
        days_ago: 5,
        tags: &["détente", "coop"],
        notes: "Fermer la saison d'automne. Communauté terminée à 80 %.",
    },
    DemoSpec {
        name: "Elden Ring",
        developer: "FromSoftware",
        genres: &["Action", "RPG", "Monde ouvert"],
        released: "25 février 2022",
        description: "L'Anneau ancien a été brisé. Parcourez les Terres intermédiaires, forgez votre propre chemin et affrontez des demi-dieux dans un monde ouvert signé FromSoftware et George R. R. Martin.",
        status: GameStatus::Backlog,
        favorite: false,
        hours: 0.0,
        days_ago: 0,
        tags: &["difficile", "monde ouvert"],
        notes: "",
    },
    DemoSpec {
        name: "Baldur's Gate 3",
        developer: "Larian Studios",
        genres: &["RPG", "Tactique", "Coopération"],
        released: "3 août 2023",
        description: "Rassemblez votre groupe, résistez au parasite et traversez une aventure à embranchements. Chaque choix pèse, chaque combat se prépare, et le multijoueur change la donne.",
        status: GameStatus::Playing,
        favorite: true,
        hours: 64.8,
        days_ago: 1,
        tags: &["coop", "histoire", "long terme"],
        notes: "Acte II. Garder Astarion dans l'équipe pour la quête du palais.",
    },
    DemoSpec {
        name: "Ori and the Blind Forest",
        developer: "Moon Studios",
        genres: &["Metroidvania", "Plateforme"],
        released: "11 mars 2015",
        description: "Un conte visuel et musical dans une forêt qui se meurt. Ori court, saute et restaure la lumière, porté par une direction artistique peinte à la main.",
        status: GameStatus::Finished,
        favorite: false,
        hours: 12.3,
        days_ago: 120,
        tags: &["visuel", "musique"],
        notes: "",
    },
    DemoSpec {
        name: "Slay the Spire",
        developer: "Mega Crit",
        genres: &["Deckbuilding", "Roguelike", "Stratégie"],
        released: "23 janvier 2019",
        description: "Construisez votre deck, gravissez la Flèche et adaptez-vous à chaque rencontre. Un roguelike de cartes dont chaque partie raconte une stratégie différente.",
        status: GameStatus::Playing,
        favorite: false,
        hours: 54.7,
        days_ago: 4,
        tags: &["cartes", "roguelike"],
        notes: "Montée 18 avec la Silencieuse.",
    },
    DemoSpec {
        name: "Cyberpunk 2077",
        developer: "CD Projekt Red",
        genres: &["RPG", "Action", "Monde ouvert"],
        released: "10 décembre 2020",
        description: "Night City, ses implants, ses gangs et ses promesses. Incarnez V, poursuivez un implant volé et décidez de ce que vous êtes prêt à sacrifier.",
        status: GameStatus::Dropped,
        favorite: false,
        hours: 9.4,
        days_ago: 210,
        tags: &["monde ouvert"],
        notes: "Abandonné après l'acte I. À retenter avec le mode Phantom Liberty.",
    },
    DemoSpec {
        name: "A Short Hike",
        developer: "Adam Robinson-Yu",
        genres: &["Aventure", "Détente", "Exploration"],
        released: "30 juillet 2019",
        description: "Une île, des sentiers, des mouettes et un sommet à atteindre. Un jeu court et chaleureux où l'on prend son temps, sans pression.",
        status: GameStatus::Finished,
        favorite: false,
        hours: 3.1,
        days_ago: 45,
        tags: &["court", "détente"],
        notes: "",
    },
    DemoSpec {
        name: "Signalis",
        developer: "rose-engine",
        genres: &["Horreur", "Survival", "Mystère"],
        released: "27 octobre 2022",
        description: "Une technicienne se réveille dans une station abandonnée, à la recherche de son partenaire. Survival horror à l'ambiance rétro, entre mémoire et répétition.",
        status: GameStatus::Backlog,
        favorite: false,
        hours: 0.0,
        days_ago: 0,
        tags: &["horreur", "court"],
        notes: "",
    },
];

fn escape_xml(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn slug(text: &str) -> String {
    text.chars()
        .map(|character| {
            if character.is_alphanumeric() {
                character.to_ascii_lowercase()
            } else {
                '-'
            }
        })
        .collect()
}

fn write_demo_art(root: &Path, name: &str, hue: u16) -> (PathBuf, PathBuf) {
    let dir = root.join(format!("{hue}-{}", slug(name)));
    let _ = std::fs::create_dir_all(&dir);
    let title = escape_xml(name);
    let initial = escape_xml(
        &name
            .chars()
            .next()
            .unwrap_or('Q')
            .to_uppercase()
            .to_string(),
    );
    let cover = format!(
        r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 900">
<defs>
<linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="hsl({hue}, 62%, 16%)"/>
<stop offset="0.55" stop-color="hsl({hue2}, 55%, 9%)"/>
<stop offset="1" stop-color="#05060a"/>
</linearGradient>
<radialGradient id="r" cx="0.82" cy="0.16" r="0.75">
<stop offset="0" stop-color="hsl({hue}, 95%, 62%)" stop-opacity="0.85"/>
<stop offset="1" stop-color="hsl({hue}, 95%, 62%)" stop-opacity="0"/>
</radialGradient>
<filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope="0.045"/></feComponentTransfer></filter>
</defs>
<rect width="600" height="900" fill="url(#g)"/>
<rect width="600" height="900" fill="url(#r)"/>
<circle cx="470" cy="180" r="250" fill="none" stroke="hsl({hue}, 90%, 72%)" stroke-opacity="0.18" stroke-width="1.5"/>
<circle cx="470" cy="180" r="168" fill="none" stroke="hsl({hue}, 90%, 72%)" stroke-opacity="0.12"/>
<circle cx="470" cy="180" r="92" fill="hsl({hue}, 90%, 60%)" fill-opacity="0.10"/>
<text x="300" y="520" text-anchor="middle" font-family="Archivo, DejaVu Sans, sans-serif" font-size="360" font-weight="800" fill="#ffffff" fill-opacity="0.10">{initial}</text>
<rect x="44" y="700" width="512" height="3" fill="hsl({hue}, 90%, 70%)" fill-opacity="0.35"/>
<text x="44" y="758" font-family="Archivo, DejaVu Sans, sans-serif" font-size="30" font-weight="600" fill="#ffffff" fill-opacity="0.82">{title}</text>
<rect width="600" height="900" filter="url(#n)"/>
</svg>"##,
        hue = hue,
        hue2 = (hue + 42) % 360,
        initial = initial,
        title = title,
    );
    let hero = format!(
        r##"<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 720">
<defs>
<linearGradient id="g" x1="0" y1="0" x2="1" y2="0.7">
<stop offset="0" stop-color="hsl({hue}, 55%, 13%)"/>
<stop offset="0.5" stop-color="hsl({hue2}, 48%, 8%)"/>
<stop offset="1" stop-color="#04050a"/>
</linearGradient>
<radialGradient id="r" cx="0.76" cy="0.2" r="0.7">
<stop offset="0" stop-color="hsl({hue}, 92%, 58%)" stop-opacity="0.55"/>
<stop offset="1" stop-color="hsl({hue}, 92%, 58%)" stop-opacity="0"/>
</radialGradient>
<filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope="0.04"/></feComponentTransfer></filter>
</defs>
<rect width="1920" height="720" fill="url(#g)"/>
<rect width="1920" height="720" fill="url(#r)"/>
<circle cx="1500" cy="120" r="430" fill="none" stroke="hsl({hue}, 92%, 70%)" stroke-opacity="0.14" stroke-width="2"/>
<circle cx="1500" cy="120" r="300" fill="none" stroke="hsl({hue}, 92%, 70%)" stroke-opacity="0.10"/>
<path d="M0 560 C 380 480, 640 650, 980 540 S 1600 430, 1920 520 L1920 720 L0 720 Z" fill="#03040a" fill-opacity="0.45"/>
<text x="1370" y="600" font-family="Archivo, DejaVu Sans, sans-serif" font-size="520" font-weight="800" fill="#ffffff" fill-opacity="0.07">{initial}</text>
<rect width="1920" height="720" filter="url(#n)"/>
</svg>"##,
        hue = hue,
        hue2 = (hue + 42) % 360,
        initial = initial,
    );
    let cover_path = dir.join("cover.svg");
    let hero_path = dir.join("hero.svg");
    let _ = std::fs::write(&cover_path, cover);
    let _ = std::fs::write(&hero_path, hero);
    (cover_path, hero_path)
}

fn demo_library(root: &Path, with_games: bool) -> Library {
    let mut library = Library::default();
    library.settings.onboarding_done = true;
    library.settings.ui_language = UiLanguage::French;
    library.settings.theme = ThemeMode::Amoled;
    library.settings.ui_compact = false;
    library.settings.hero_background = true;
    if !with_games {
        return library;
    }
    let _ = std::fs::remove_dir_all(root);
    let _ = std::fs::create_dir_all(root);
    let now = config::now_ts();
    for spec in DEMO {
        let mut game = Game::new(spec.name, "/bin/true");
        game.developer = spec.developer.to_string();
        game.genres = spec.genres.iter().map(|genre| genre.to_string()).collect();
        game.released = spec.released.to_string();
        game.description = spec.description.to_string();
        game.status = spec.status;
        game.favorite = spec.favorite;
        game.tags = spec.tags.iter().map(|tag| tag.to_string()).collect();
        game.notes = spec.notes.to_string();
        game.playtime_secs = (spec.hours * 3600.0) as u64;
        game.last_played = if spec.hours > 0.0 {
            Some(now - spec.days_ago * 86_400)
        } else {
            None
        };
        game.added_at = now - (spec.days_ago + 30) * 86_400;
        if game.playtime_secs > 0 {
            let count = 5u64;
            let part = game.playtime_secs / count;
            for index in 0..count {
                game.sessions.push(PlaySession {
                    start: now - (spec.days_ago + index as i64 * 2) * 86_400,
                    secs: part.max(60),
                });
            }
        }
        let (cover, hero) = write_demo_art(root, spec.name, hue_for(spec.name));
        game.artwork.cover = Some(cover);
        game.artwork.hero = Some(hero);
        game.normalize_installations();
        library.games.push(game);
    }
    library
}

// ---------------------------------------------------------------------------
// Surveillance des sessions
// ---------------------------------------------------------------------------

fn spawn_monitor(app: AppHandle) {
    std::thread::spawn(move || loop {
        std::thread::sleep(Duration::from_millis(1000));
        let state = app.state::<AppState>();
        let mut ended = Vec::new();
        {
            let mut sessions = lock(&state.sessions);
            let mut remove = Vec::new();
            for (id, run) in sessions.iter_mut() {
                if run.session.should_escalate() {
                    session::force_kill(&run.session);
                    run.session.escalated();
                }
                match run.session.child.try_wait() {
                    Ok(Some(_)) => remove.push(id.clone()),
                    Ok(None) => {
                        if run.session.should_abandon() {
                            remove.push(id.clone());
                        }
                    }
                    Err(_) => remove.push(id.clone()),
                }
            }
            for id in remove {
                if let Some(run) = sessions.remove(&id) {
                    ended.push((
                        id,
                        run.started_ts,
                        run.session.started.elapsed().as_secs().max(1),
                    ));
                }
            }
        }
        for (id, started, secs) in ended {
            let mut library = lock(&state.library);
            if let Some(game) = library.get_mut(&id) {
                game.record_session(started, secs);
            }
            if !state.demo {
                let _ = library.save();
            }
            let settings = library.settings.clone();
            let dto = library
                .get(&id)
                .map(|game| game_dto(game, &settings, false, None));
            drop(library);
            let _ = app.emit(
                "quark://session-ended",
                serde_json::json!({ "id": id, "secs": secs, "game": dto }),
            );
        }
    });
}

fn finalize_sessions(app: &AppHandle) {
    let state = app.state::<AppState>();
    let mut ended = Vec::new();
    {
        let mut sessions = lock(&state.sessions);
        for (id, run) in sessions.drain() {
            ended.push((
                id,
                run.started_ts,
                run.session.started.elapsed().as_secs().max(1),
            ));
        }
    }
    if ended.is_empty() {
        return;
    }
    let mut library = lock(&state.library);
    for (id, started, secs) in ended {
        if let Some(game) = library.get_mut(&id) {
            game.record_session(started, secs);
        }
    }
    if !state.demo {
        let _ = library.save();
    }
}

// ---------------------------------------------------------------------------
// Point d'entrée
// ---------------------------------------------------------------------------

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let demo = args
        .iter()
        .any(|arg| arg == "--demo" || arg == "--demo-empty");
    let empty = args.iter().any(|arg| arg == "--demo-empty");
    let demo_root = demo.then(|| std::env::temp_dir().join("quark-tauri-demo"));
    let library = match &demo_root {
        Some(root) => demo_library(root, !empty),
        None => Library::load(),
    };
    quark::i18n::set_language(library.settings.ui_language);
    let state = AppState {
        library: Mutex::new(library),
        sessions: Mutex::new(HashMap::new()),
        runtimes: if demo {
            Vec::new()
        } else {
            proton::detect_runtimes()
        },
        demo,
        demo_root,
    };

    let app = tauri::Builder::default()
        .manage(state)
        .register_uri_scheme_protocol("quarkimg", |ctx, request| {
            let state = ctx.app_handle().state::<AppState>();
            serve_asset(&state, request)
        })
        .invoke_handler(tauri::generate_handler![
            bootstrap_data,
            running_games,
            get_game,
            launch_game,
            stop_game,
            set_favorite,
            set_status,
            set_notes,
            add_tag,
            remove_tag,
            update_game,
            add_game,
            remove_game,
            open_folder,
            open_config_folder,
            read_log,
            save_settings,
            reload_library,
            pick_executable,
            pick_artwork,
            win_minimize,
            win_toggle_maximize,
            win_close,
            win_start_drag,
            win_start_resize,
            features::get_settings_raw,
            features::patch_settings_raw,
            features::get_game_raw,
            features::patch_game_raw,
            features::list_runtimes,
            features::fetch_news,
            features::fetch_hltb,
            features::fetch_protondb,
            features::disk_report,
            features::check_update,
            features::open_url,
            store::store_load,
            store::store_refresh,
            store::store_search,
        ])
        .setup(|app| {
            if let Some(window) = app.get_webview_window("main") {
                let icon = tauri::image::Image::new_owned(
                    include_bytes!("../icons/icon.rgba").to_vec(),
                    128,
                    128,
                );
                let _ = window.set_icon(icon);
            }
            spawn_monitor(app.handle().clone());
            Ok(())
        })
        .build(tauri::generate_context!())
        .expect("Quark n'a pas pu démarrer");

    app.run(|app, event| {
        if let RunEvent::ExitRequested { .. } = event {
            finalize_sessions(app);
        }
    });
}
