//! Boutique Steam : catalogue en cache, actualisation, recherche et recommandations.
//! Reprend `quark::steam_store` tel quel ; l'interface ne fait que de l'affichage.

use super::{lock, AppState};
use quark::providers::credentials;
use quark::steam_store::{self, StoreItem, StoreSnapshot};
use quark::{artwork, config};
use serde::Serialize;
use tauri::State;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PriceDto {
    currency: String,
    initial: u64,
    final_price: u64,
    discount_percent: Option<u8>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ItemDto {
    app_id: u32,
    name: String,
    price: Option<PriceDto>,
    artwork_url: Option<String>,
    store_url: String,
    linux_available: Option<bool>,
    players_peak: Option<u32>,
}

#[derive(Serialize)]
pub struct SectionDto {
    title: String,
    items: Vec<ItemDto>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct StorePageDto {
    fetched_at: i64,
    stale: bool,
    sections: Vec<SectionDto>,
    recommendations: Vec<ItemDto>,
    recommendation_source: Option<String>,
    notice: Option<String>,
}

fn item_dto(item: StoreItem) -> ItemDto {
    ItemDto {
        app_id: item.app_id,
        name: item.name,
        price: item.price.map(|price| PriceDto {
            currency: price.currency,
            initial: price.initial,
            final_price: price.final_price,
            discount_percent: price.discount_percent,
        }),
        artwork_url: item.artwork_url,
        store_url: item.store_url,
        linux_available: item.linux_available,
        players_peak: item.players_peak,
    }
}

fn page_dto(
    snapshot: StoreSnapshot,
    games: &[config::Game],
    steam_library: Option<&[steam_store::OwnedSteamGame]>,
    notice: Option<String>,
) -> StorePageDto {
    let (recommendations, source) = steam_store::recommendations_for(Some(&snapshot), games, steam_library);
    StorePageDto {
        fetched_at: snapshot.fetched_at,
        stale: snapshot.is_stale(config::now_ts()),
        sections: snapshot
            .sections
            .into_iter()
            .map(|section| SectionDto { title: section.title, items: section.items.into_iter().map(item_dto).collect() })
            .collect(),
        recommendations: recommendations.into_iter().map(item_dto).collect(),
        recommendation_source: source,
        notice,
    }
}

/// Catalogue enregistré lors de la dernière actualisation (affichage immédiat).
#[tauri::command]
pub fn store_load(state: State<'_, AppState>) -> Option<StorePageDto> {
    let snapshot = steam_store::load_cache(&steam_store::cache_path()).ok().flatten()?;
    let games = lock(&state.library).games.clone();
    Some(page_dto(snapshot, &games, None, None))
}

/// Recharge les catégories, les jeux les plus joués et, si une clé Web API est
/// enregistrée, la bibliothèque Steam du compte (pour mieux recommander).
#[tauri::command]
pub async fn store_refresh(state: State<'_, AppState>) -> Result<StorePageDto, String> {
    let (games, language, country) = {
        let library = lock(&state.library);
        (library.games.clone(), library.settings.language.clone(), library.settings.country.clone())
    };
    tauri::async_runtime::spawn_blocking(move || {
        let creds = credentials::load(&config::credentials_path()).unwrap_or_default();
        let fetch = steam_store::fetch_all(
            &artwork::http(),
            &language,
            &country,
            creds.steam_web_api_key.as_deref(),
            creds.steam_id.as_deref(),
        )?;
        let _ = steam_store::save_cache_atomic(&steam_store::cache_path(), &fetch.snapshot);
        let notice = fetch.popular_error.or(fetch.steam_library_error);
        Ok(page_dto(fetch.snapshot, &games, fetch.steam_library.as_deref(), notice))
    })
    .await
    .map_err(|error| error.to_string())?
}

#[tauri::command]
pub async fn store_search(state: State<'_, AppState>, query: String) -> Result<Vec<ItemDto>, String> {
    let (language, country) = {
        let library = lock(&state.library);
        (library.settings.language.clone(), library.settings.country.clone())
    };
    tauri::async_runtime::spawn_blocking(move || {
        steam_store::search(&artwork::http(), query.trim(), &language, &country)
            .map(|items| items.into_iter().map(item_dto).collect())
    })
    .await
    .map_err(|error| error.to_string())?
}
