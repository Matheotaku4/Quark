# Troubleshooting

> [Home](Home) · [Installation](Installation) ·
> [Proton and Wine](Proton-Wine-and-Launch-Options) · **Troubleshooting**

Before changing a prefix or deleting a file, back up the folder involved. Most
problems are diagnosed with a log, not by resetting the library.

## Check the environment

```bash
quark --doctor
```

This command checks the local elements Quark needs: display, tools and paths. It
changes nothing.

For a launch outside the interface:

```bash
quark list
quark launch "Hollow Knight"
quark --search "Hollow Knight"
quark --news 367520
```

## A game does not start

1. Open the game page and check **Game settings**.
2. Check that the executable still exists. A moved or uninstalled game leaves an
   entry with a dead path; Quark shows it in red.
3. Check the Proton runtime. **Automatic** chooses an installed runtime; if none
   is detected, install Proton in Steam or place a build in
   `compatibilitytools.d/`.
4. Enable **PROTON_LOG** and launch again.
5. Read the log in `~/.local/share/quark/logs/<game>/`.
6. Try another Proton runtime before touching the prefix.

### Common errors

| Message | Likely cause | Action |
| --- | --- | --- |
| `Executable not found` | Path moved or game uninstalled | Fix the executable on the game page. |
| `Runtime ... not found` | Proton runtime deleted | Choose another runtime or reinstall Proton. |
| `umu-run not found` | umu-launcher missing | Install umu or uncheck the option. |
| `gamemoderun is not installed` | GameMode missing | Install GameMode or uncheck the option; the game still starts. |
| `gamescope is not installed` | gamescope missing | Install gamescope or uncheck the option. |
| Anti-cheat runtime not found | BattlEye/EAC runtime missing | Install the matching Steam runtime, then detect again. |

A missing graphics tool is reported and ignored: Quark continues without it
rather than failing. A missing Proton runtime, however, prevents the launch.

## Black screen, crash or return to desktop

- Enable `PROTON_LOG=1` and read the last lines of the log.
- Try another Proton runtime.
- Try `PROTON_USE_WINED3D=1` only as a compatibility test: if the game starts,
  the problem is probably DXVK/VKD3D or the driver.
- Update the graphics driver.
- Check whether the game needs an extra Windows DLL or component. Quark does not
  run `winetricks` automatically.
- Do not delete the prefix immediately: move it first so you can roll back.

## Controller, sound, mouse

- **Controller**: check udev/Steam Input, try without gamescope, read the log. A
  game that uses Steam Input may require launching through Steam.
- **Sound**: try `PULSE_LATENCY_MSEC=60`, check the system's default device, then
  test without a wrapper.
- **Captured mouse**: try the game's windowed mode, `-windowed` in the arguments,
  or disable gamescope.
- **Wrong GPU**: uncheck PRIME on a single-GPU desktop, or check `DRI_PRIME` on
  an AMD laptop.

## The interface does not open

- Check that `DISPLAY` or `WAYLAND_DISPLAY` is set.
- Try X11/XWayland if the Wayland compositor refuses to create the window.
- Check OpenGL and the drivers.
- Run `quark --doctor`.
- Read the terminal output: a font or graphics-context loading error appears
  there.

## Language problem

- The interface language is changed in **Settings → Appearance → Interface
  language**.
- The Steam page language is a separate setting in **Stores & tools**.
- Game names, tags and personal genres are not translated.
- If a text stays in the source language after switching, it is probably user
  data or a newly added string without a catalogue entry. Note the page and exact
  text to report it.

## The random hero background does not appear

- The library needs at least one banner artwork.
- The background is drawn behind Home and Library; it can be subtle under cards
  and the readability veil.
- The pick changes on restart, not on every navigation.
- Increase the blur or check that the option is enabled in **Appearance**.

## Settings

Since 1.2, settings fill the window and scroll. If the **Close** button is not
visible, `Escape` closes the page. If content looks cut off, resize the window:
the layout is responsive but some blocks need a minimum width.

## Media and trailers

- **The trailer stutters or only advances when the mouse moves**: fixed in
  1.8.7. The player now schedules its own repaints instead of waiting for an
  input event. On an older build, keep moving the pointer over the window or
  update Quark.
- **No volume slider under the trailer**: the slider controls the
  PulseAudio/PipeWire stream of the GStreamer process and needs `pactl`
  (`pulseaudio-utils` on Debian/Ubuntu, `libpulse` on Arch) plus a running
  PulseAudio or PipeWire server. With a direct ALSA sink the trailer still
  plays, but its volume must be changed with the system mixer. If `pulsesink`
  fails before the first frame, Quark retries with `autoaudiosink`; the trailer
  plays, but the slider stays hidden because that output cannot be controlled
  through `pactl`.

## Legendary, gogdl and accounts

- **Legendary not found**: check `python3`, then reinstall the tool in **Stores &
  tools**. Quark verifies the SHA-256 before running it.
- **Epic login refused**: the authorization code is time-limited; start the
  connection again. Quark exchanges it directly with Epic.
- **GOG session expired**: reconnect GOG; the token is in a separate file with
  private permissions.
- **A store game does not appear**: run a synchronization and check that the
  account is connected and the game is owned.
- **GOG installation fails with "Not enough disk space" while the game is
  already installed**: Quark now recognizes the existing `goggame-<id>.info`
  before starting gogdl and adopts the folder instead of downloading it again.
  The folder must be complete: the primary executable and every `game`-category
  executable declared in the manifest's `playTasks` have to exist, and a
  gogdl/Galaxy resume marker blocks adoption. Optional manuals, configuration
  tools and URLTask entries do not block it.
  Retry **Install** once; if the game is in another folder, point the
  installation folder at it first. If a synchronization returns the game to
  **Not installed**, the declared executable is missing: let gogdl repair the
  installation instead of forcing it installed.
- **No Epic overlay in game**: the overlay is a separate download. Launching
  an Epic game now offers **Install and launch** when it is missing. The game
  starts after the download, and the overlay is enabled in the prefix when it
  already exists. An overlay installed inside the game prefix (Epic Games
  Launcher, EOS artifacts or `OverlayPath`) is recognized too. You can also
  install it from **Settings → Stores & tools → Install the Epic overlay
  (EOS)**. A new Wine prefix activates it on the following launch. `Shift+F3`
  opens it in game.
- **Epic shows connected without a direct session**: Quark now distinguishes a
  direct Epic session from a Legendary session. A Legendary connection is
  enough to install and launch, but direct account actions require the direct
  connection.

## Cloud saves

- **Epic**: `legendary sync-saves` compares local and cloud, the most recent
  wins. A custom folder may be required.
- **GOG**: gogdl requires an explicit save folder. Without it, synchronization
  cannot work.
- **Steam**: Steam Cloud remains managed by Steam; Quark does not synchronize it.
- **Conflict**: back up the local folder before letting the cloud overwrite
  anything. Quark never invents a missing save.

## Ludusavi snapshots

- **No game detected**: check the Ludusavi configuration and the save folder.
- **Restore refused**: symbolic links, `$HOME` as a root and paths outside
  allowed roots are deliberately refused.
- **Wrong snapshot restored**: each store installation has its own compartment;
  check the active installation.
- **Unreadable configuration**: Quark keeps it and reports the error; do not
  overwrite it with an empty configuration.

## Update blocked

- **Development binary**: automatic updates are ignored.
- **Read-only folder**: download the archive and replace the binary manually.
- **Game running**: close the game before installing.
- **Invalid checksum**: the archive is refused. Download the archive and
  `.sha256` again from the release.
- **Old binary kept**: Quark keeps the previous executable until the next
  successful start.

See [Installation](Installation) for the manual procedure.

## Configuration file

`~/.config/quark/config.json` contains games, installations, settings and
statistics. If it is corrupted:

- Quark copies the file to `config.json.corrompu-<timestamp>`;
- the library switches to read-only so data is not overwritten;
- an empty file is never written in its place.

Do not delete this file to solve a launch problem: the problem is almost always
in the prefix, runtime or game files, not in the library.

## Logs and privacy

Session logs are in `~/.local/share/quark/logs/<game>/`, mode `0600`. They do not
contain full environment values, complete command lines or the achievement
token. Before sharing a log, read it again: a game may write personal paths
there.

## Report a bug

Include:

- the Quark version (visible in **About**);
- the distribution, X11/Wayland session and driver version;
- the Proton runtime and enabled options;
- the last lines of the Proton log;
- reproducible steps.

Do not attach `credentials.json`, `user.json`, `gogdl-auth.json` or an API token.
Those files contain account secrets.

## See also

- [Installation](Installation)
- [Proton, Wine and launch options](Proton-Wine-and-Launch-Options)
- [Stores and saves](Stores-and-Saves)
- [Overlay and achievements](Overlay-and-Achievements)

---

[Home](Home) · [Installation](Installation) · [Proton](Proton-Wine-and-Launch-Options) · [Stores](Stores-and-Saves)
